"""
Control de inventario para pequeños negocios (versión Python + Flet).

Es la traducción del proyecto Java (Swing). Hace lo mismo:
  - Agregar, editar y eliminar productos.
  - Alertas de color: rojo = caducado, naranja = caduca en 30 días, amarillo = stock bajo.
  - Resumen arriba (caducados, por caducar, stock bajo, valor del inventario).
  - Campo de escáner: se escanea (o escribe) un código y Enter lo agrega a la venta.
  - Buscador por nombre o código.

Diferencia con el original: los datos se guardan en JSON (no en CSV)
en ~/.inventario/inventario.json

Librerías usadas: flet, os, sys, json, time.
Instalar Flet con:  pip install flet
Ejecutar con:       python inventario_flet.py
"""

import json          # leer y guardar el archivo de datos
import os            # rutas de archivos y carpetas
import sys           # argumentos del programa, mensajes de error y salir
import time          # fechas (caducidad) y hora de los mensajes

import flet as ft    # la interfaz gráfica

# ----------------------------------------------------------------------
# Colores de la interfaz (arriba para cambiarlos fácil)
# ----------------------------------------------------------------------
AZUL_OSCURO = "#213555"
VERDE = "#2EA064"
AZUL = "#3478D2"
ROJO = "#CD4141"
NARANJA = "#EB8C28"
AMARILLO = "#C8960A"
GRIS = "#78828C"
FONDO = "#F5F7FA"

# Colores de las filas de la tabla según su alerta
FILA_SELECCIONADA = "#A0C3F0"   # azul
FILA_CADUCADO = "#FAD2D2"       # rojo claro
FILA_POR_CADUCAR = "#FFE6C3"    # naranja claro
FILA_STOCK_BAJO = "#FFF6BE"     # amarillo claro
FILA_NORMAL = "#FFFFFF"         # sin alerta

FORMATO_FECHA = "%Y-%m-%d"      # AAAA-MM-DD
SEGUNDOS_POR_DIA = 86400


# ----------------------------------------------------------------------
# Funciones de fechas (usan solo el módulo time)
# ----------------------------------------------------------------------
def medianoche_de_hoy():
    """Devuelve hoy a las 00:00 en segundos, para comparar solo días y no horas."""
    ahora = time.localtime()
    return time.mktime((ahora.tm_year, ahora.tm_mon, ahora.tm_mday, 0, 0, 0, 0, 0, -1))


def fecha_a_segundos(texto):
    """Convierte 'AAAA-MM-DD' a segundos. Lanza ValueError si la fecha está mal escrita."""
    try:
        f = time.strptime(texto.strip(), FORMATO_FECHA)
        return time.mktime((f.tm_year, f.tm_mon, f.tm_mday, 0, 0, 0, 0, 0, -1))
    except (ValueError, OverflowError):
        raise ValueError("La fecha debe ser AAAA-MM-DD, por ejemplo 2027-03-15")


def normalizar_fecha(texto):
    """Devuelve la fecha siempre como AAAA-MM-DD (por ejemplo 2027-3-5 -> 2027-03-05)."""
    fecha_a_segundos(texto)  # si está mal, aquí se lanza el error
    return time.strftime(FORMATO_FECHA, time.strptime(texto.strip(), FORMATO_FECHA))


# ----------------------------------------------------------------------
# Producto: guarda los datos y sabe decir si tiene alguna alerta
# ----------------------------------------------------------------------
class Producto:
    def __init__(self, id, codigo, nombre, precio, caducidad, stock, stock_minimo):
        self.id = id                          # número único (1, 2, 3...)
        self.codigo = codigo.strip()          # código de barras o QR
        self.nombre = nombre.strip()          # nombre, por ejemplo "Leche"
        self.precio = precio                  # precio de venta
        self.caducidad = caducidad            # texto 'AAAA-MM-DD'
        self.stock = stock                    # piezas que hay ahorita
        self.stock_minimo = stock_minimo      # con esta cantidad o menos avisamos

    # --- Convertir de/hacia diccionario (así se guarda en el JSON) ---
    def a_dict(self):
        return {
            "id": self.id,
            "codigo": self.codigo,
            "nombre": self.nombre,
            "precio": self.precio,
            "caducidad": self.caducidad,
            "stock": self.stock,
            "minimo": self.stock_minimo,
        }

    @staticmethod
    def desde_dict(d):
        """Crea un Producto desde un diccionario leído del JSON."""
        return Producto(
            int(d["id"]),
            str(d["codigo"]),
            str(d["nombre"]),
            float(d["precio"]),
            normalizar_fecha(str(d["caducidad"])),
            int(d["stock"]),
            int(d["minimo"]),
        )

    # --- Alertas ---
    def dias_para_caducar(self):
        """Días que faltan para caducar (negativo si ya caducó)."""
        # round() evita errores de una hora por el cambio de horario de verano
        return round((fecha_a_segundos(self.caducidad) - medianoche_de_hoy()) / SEGUNDOS_POR_DIA)

    def esta_caducado(self):
        """¿Ya pasó la fecha de caducidad?"""
        return self.dias_para_caducar() < 0

    def caduca_pronto(self):
        """¿Caduca en los próximos 30 días? (si ya caducó no cuenta, es otra alerta)"""
        return not self.esta_caducado() and self.dias_para_caducar() <= 30

    def stock_bajo(self):
        """¿Se está acabando? True cuando el stock llegó al mínimo o por debajo."""
        return self.stock <= self.stock_minimo

    def alerta(self):
        """Texto de la columna 'Alerta' (un producto puede tener dos alertas)."""
        texto = ""
        if self.esta_caducado():
            texto = "CADUCADO"
        elif self.caduca_pronto():
            texto = "Caduca pronto"
        if self.stock_bajo():
            if texto:
                texto += " + "      # separamos las dos alertas con un +
            texto += "Stock bajo"
        return texto


# ----------------------------------------------------------------------
# Inventario: toda la lógica (agregar, editar, eliminar, vender, guardar)
# ----------------------------------------------------------------------
class Inventario:
    def __init__(self, ruta):
        self.ruta = ruta          # dónde se guarda el JSON
        self.productos = []       # lista de Producto en memoria
        self.cargar()

    # ---------- Agregar, editar y eliminar ----------
    def agregar(self, producto):
        self.validar(producto)                  # si algo está mal, lanza ValueError
        producto.id = self.siguiente_id()       # id nuevo = el más grande + 1
        self.productos.append(producto)
        self.guardar()

    def actualizar(self, producto):
        self.validar(producto)
        viejo = self.buscar_por_id(producto.id)
        if viejo is None:
            raise ValueError("El producto no existe.")
        self.productos[self.productos.index(viejo)] = producto   # reemplazamos el viejo
        self.guardar()

    def eliminar(self, id):
        producto = self.buscar_por_id(id)
        if producto is None:
            raise ValueError("El producto no existe.")
        self.productos.remove(producto)
        self.guardar()

    def actualizar_por_codigo(self, codigo, datos):
        viejo = self.buscar_por_codigo(codigo)
        if viejo is None:
            raise ValueError("El producto no existe.")
        datos.id = viejo.id           # conserva el mismo id
        self.actualizar(datos)
        return datos

    def eliminar_por_codigo(self, codigo):
        producto = self.buscar_por_codigo(codigo)
        if producto is None:
            raise ValueError("El producto no existe.")
        self.eliminar(producto.id)

    # ---------- Ventas ----------
    def vender_por_codigo(self, codigo, cantidad=1):
        """Vende 'cantidad' piezas del producto con ese código."""
        producto = self.buscar_por_codigo(codigo)
        if producto is None:
            raise ValueError(f"No hay ningún producto con el código {codigo}")
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser mayor que cero.")
        if producto.stock < cantidad:
            raise ValueError(f"No hay suficiente stock de {producto.nombre}.")
        producto.stock -= cantidad
        self.guardar()
        return producto

    def vender_por_codigos(self, cantidades):
        """
        Vende varios artículos a la vez. 'cantidades' es {codigo: piezas}.
        Primero revisa TODO y solo si todo está bien descuenta el stock,
        así nunca queda una venta a medias.
        """
        if not cantidades:
            raise ValueError("La venta no tiene artículos.")
        # 1) Revisamos todos los artículos sin tocar nada
        for codigo, cantidad in cantidades.items():
            producto = self.buscar_por_codigo(codigo)
            if producto is None:
                raise ValueError(f"No hay ningún producto con el código {codigo}")
            if cantidad <= 0:
                raise ValueError("La cantidad debe ser mayor que cero.")
            if producto.stock < cantidad:
                raise ValueError(f"No hay suficiente stock de {producto.nombre}.")
        # 2) Todo está bien: ahora sí descontamos
        for codigo, cantidad in cantidades.items():
            self.buscar_por_codigo(codigo).stock -= cantidad
        self.guardar()

    # ---------- Búsquedas ----------
    def buscar_por_id(self, id):
        for p in self.productos:
            if p.id == id:
                return p
        return None

    def buscar_por_codigo(self, codigo):
        for p in self.productos:
            if p.codigo and p.codigo == codigo:
                return p
        return None

    # ---------- Números del resumen ----------
    def contar_caducados(self):
        return sum(1 for p in self.productos if p.esta_caducado())

    def contar_por_caducar(self):
        return sum(1 for p in self.productos if p.caduca_pronto())

    def contar_stock_bajo(self):
        return sum(1 for p in self.productos if p.stock_bajo())

    def valor_total(self):
        """Dinero que hay en mercancía (precio x piezas de cada producto)."""
        return sum(p.precio * p.stock for p in self.productos)

    # ---------- Cosas internas ----------
    def validar(self, p):
        """Revisa que los datos tengan sentido antes de guardarlos."""
        if not p.nombre:
            raise ValueError("El nombre es obligatorio.")
        if p.precio < 0:
            raise ValueError("El precio no puede ser negativo.")
        if not p.caducidad:
            raise ValueError("La caducidad es obligatoria.")
        fecha_a_segundos(p.caducidad)    # lanza error si el formato es incorrecto
        if p.stock < 0:
            raise ValueError("El stock no puede ser negativo.")
        if p.stock_minimo < 0:
            raise ValueError("El stock mínimo no puede ser negativo.")
        if not p.codigo:
            raise ValueError("El código es obligatorio.")
        # Dos productos no pueden tener el mismo código
        for otro in self.productos:
            if otro.codigo == p.codigo and otro.id != p.id:
                raise ValueError("Ya existe un producto con ese código.")

    def siguiente_id(self):
        """Busca el id más grande que hay y le suma 1."""
        return max((p.id for p in self.productos), default=0) + 1

    def cargar(self):
        """Lee el archivo JSON y llena la lista de productos."""
        if not os.path.exists(self.ruta):
            return   # primera vez que se usa: no hay archivo, empezamos vacíos
        try:
            with open(self.ruta, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
        except (OSError, json.JSONDecodeError) as error:
            raise RuntimeError(f"No se pudo leer el inventario: {error}")

        for d in datos.get("productos", []):
            try:
                self.productos.append(Producto.desde_dict(d))
            except (KeyError, ValueError, TypeError):
                # si un producto está dañado lo ignoramos para que el programa no se caiga
                sys.stderr.write(f"Producto ignorado por datos dañados: {d}\n")

    def guardar(self):
        """Escribe todos los productos en el archivo JSON."""
        datos = {"productos": [p.a_dict() for p in self.productos]}
        try:
            os.makedirs(os.path.dirname(os.path.abspath(self.ruta)), exist_ok=True)
            # Escribimos en un archivo temporal y luego lo renombramos:
            # así, si el programa se cierra a la mitad, no se daña el archivo bueno.
            temporal = self.ruta + ".tmp"
            with open(temporal, "w", encoding="utf-8") as archivo:
                json.dump(datos, archivo, ensure_ascii=False, indent=2)
            os.replace(temporal, self.ruta)
        except OSError as error:
            raise RuntimeError(f"No se pudo guardar el inventario: {error}")


# ----------------------------------------------------------------------
# Interfaz gráfica (Flet)
# ----------------------------------------------------------------------
def crear_boton(texto, color, al_hacer_clic):
    """Botón con color de fondo y letras blancas."""
    # En Flet 1.0 el botón se llama Button; en versiones anteriores, ElevatedButton
    clase_boton = getattr(ft, "Button", None) or ft.ElevatedButton
    return clase_boton(texto, bgcolor=color, color="#FFFFFF", on_click=al_hacer_clic)


def main(page: ft.Page, inventario: Inventario):
    # ---------- Ventana ----------
    page.title = "Control de inventario"
    page.bgcolor = FONDO
    page.padding = 0
    page.scroll = ft.ScrollMode.AUTO

    codigo_seleccionado = ""     # código del producto elegido en la tabla ("" = ninguno)
    venta_pendiente = {}         # artículos de la venta en curso: {codigo: cantidad}

    # ---------- Resumen de arriba ----------
    num_caducados = ft.Text("0", size=26, weight=ft.FontWeight.BOLD, color="#FFFFFF")
    num_por_caducar = ft.Text("0", size=26, weight=ft.FontWeight.BOLD, color="#FFFFFF")
    num_stock_bajo = ft.Text("0", size=26, weight=ft.FontWeight.BOLD, color="#FFFFFF")
    num_valor = ft.Text("$0.00", size=26, weight=ft.FontWeight.BOLD, color="#FFFFFF")

    def tarjeta(titulo, numero, color):
        """Una tarjeta de color: título chiquito y número grande."""
        return ft.Container(
            content=ft.Column([ft.Text(titulo, color="#FFFFFF"), numero], spacing=2),
            bgcolor=color, padding=12, border_radius=6, expand=1,
        )

    resumen = ft.Row(
        [
            tarjeta("Caducados", num_caducados, ROJO),
            tarjeta("Caducan en 30 días", num_por_caducar, NARANJA),
            tarjeta("Stock bajo", num_stock_bajo, AMARILLO),
            tarjeta("Valor del inventario", num_valor, VERDE),
        ],
        spacing=10,
    )

    # ---------- Campos de arriba: escáner, cantidad y buscador ----------
    campo_escaner = ft.TextField(
        label="Escanear código", border_color=VERDE, expand=2, dense=True,
        on_submit=lambda e: agregar_a_venta(e),     # Enter (el lector lo presiona solo)
    )
    campo_cantidad = ft.TextField(
        label="Cantidad", value="1", width=100, dense=True, text_align=ft.TextAlign.CENTER,
        on_submit=lambda e: agregar_a_venta(e),
    )
    campo_buscar = ft.TextField(
        label="Buscar por nombre o código", expand=2, dense=True,
        on_change=lambda e: actualizar_tabla(),     # se filtra mientras se escribe
    )

    texto_venta = ft.Text("Sin artículos", expand=True)   # lista de la venta en curso

    # ---------- Campos del formulario de abajo ----------
    campo_codigo = ft.TextField(label="Código", width=170, dense=True)
    campo_nombre = ft.TextField(label="Nombre", width=200, dense=True)
    campo_precio = ft.TextField(label="Precio", width=110, dense=True)
    campo_caducidad = ft.TextField(label="Caducidad (AAAA-MM-DD)", width=190, dense=True)
    campo_stock = ft.TextField(label="Stock", width=90, dense=True)
    campo_minimo = ft.TextField(label="Stock mínimo", width=120, dense=True)

    # ---------- Mensaje de estado (abajo) ----------
    etiqueta_estado = ft.Text(" ", weight=ft.FontWeight.BOLD, size=14)

    def mostrar_estado(mensaje, color):
        """Mensaje de color con la hora, por ejemplo: [14:32:10] Producto agregado."""
        hora = time.strftime("%H:%M:%S")
        etiqueta_estado.value = f"[{hora}] {mensaje}"
        etiqueta_estado.color = color
        page.update()

    def mostrar_error(mensaje):
        mostrar_estado(mensaje, ROJO)

    def enfocar(campo):
        """Regresa el cursor a un campo (útil para seguir escaneando)."""
        try:
            campo.focus()
            page.update()
        except Exception:
            pass   # si esta versión de Flet no lo permite, no pasa nada

    # ---------- Tabla (hecha con filas clicables) ----------
    filas = ft.Column(spacing=1, scroll=ft.ScrollMode.AUTO, height=280)

    def celda(texto, expand, color="#000000", negrita=False):
        """Una celda de texto de la tabla."""
        return ft.Text(
            str(texto), expand=expand, size=13, color=color,
            weight=ft.FontWeight.BOLD if negrita else ft.FontWeight.NORMAL,
        )

    # Encabezado azul oscuro con letras blancas
    encabezado = ft.Container(
        content=ft.Row([
            celda("Código", 3, "#FFFFFF", True), celda("Nombre", 3, "#FFFFFF", True),
            celda("Precio", 1, "#FFFFFF", True), celda("Caducidad", 2, "#FFFFFF", True),
            celda("Stock", 1, "#FFFFFF", True), celda("Mínimo", 1, "#FFFFFF", True),
            celda("Alerta", 3, "#FFFFFF", True),
        ]),
        bgcolor=AZUL_OSCURO, padding=8,
    )

    def color_de_fila(p):
        """Elige el color de fondo de la fila según su alerta."""
        alerta = p.alerta()
        if p.codigo == codigo_seleccionado:
            return FILA_SELECCIONADA
        if "CADUCADO" in alerta:
            return FILA_CADUCADO
        if "Caduca pronto" in alerta:
            return FILA_POR_CADUCAR
        if "Stock bajo" in alerta:
            return FILA_STOCK_BAJO
        return FILA_NORMAL

    def crear_fila(p):
        """Fila de la tabla para un producto; al hacer clic se selecciona."""
        return ft.Container(
            content=ft.Row([
                celda(p.codigo, 3), celda(p.nombre, 3), celda(f"{p.precio:.2f}", 1),
                celda(p.caducidad, 2), celda(p.stock, 1), celda(p.stock_minimo, 1),
                celda(p.alerta(), 3),
            ]),
            bgcolor=color_de_fila(p), padding=8,
            on_click=lambda e, c=p.codigo: seleccionar(c),
        )

    def actualizar_tabla():
        """Vuelve a llenar la tabla (con el filtro del buscador) y actualiza el resumen."""
        texto = (campo_buscar.value or "").strip().lower()
        filas.controls.clear()
        for p in inventario.productos:
            if not texto or texto in p.nombre.lower() or texto in p.codigo.lower():
                filas.controls.append(crear_fila(p))

        # Los números cuentan todos los productos, aunque el buscador filtre
        num_caducados.value = str(inventario.contar_caducados())
        num_por_caducar.value = str(inventario.contar_por_caducar())
        num_stock_bajo.value = str(inventario.contar_stock_bajo())
        num_valor.value = f"${inventario.valor_total():.2f}"
        page.update()

    # ---------- Formulario ----------
    def leer_formulario():
        """Convierte lo que escribió el usuario en un Producto (o lanza ValueError)."""
        codigo = (campo_codigo.value or "").strip()
        nombre = (campo_nombre.value or "").strip()

        try:
            # cambiamos coma por punto por si escriben 25,50
            precio = float((campo_precio.value or "").strip().replace(",", "."))
        except ValueError:
            raise ValueError("El precio debe ser un número, por ejemplo 25.50")

        caducidad = normalizar_fecha(campo_caducidad.value or "")

        try:
            stock = int((campo_stock.value or "").strip())
        except ValueError:
            raise ValueError("El stock debe ser un número entero.")

        minimo = 10   # si dejan el mínimo vacío usamos 10
        texto_minimo = (campo_minimo.value or "").strip()
        if texto_minimo:
            try:
                minimo = int(texto_minimo)
            except ValueError:
                raise ValueError("El stock mínimo debe ser un número entero.")

        return Producto(0, codigo, nombre, precio, caducidad, stock, minimo)

    def limpiar_formulario(e=None):
        """Vacía el formulario y quita la selección."""
        nonlocal codigo_seleccionado
        codigo_seleccionado = ""
        for campo in (campo_codigo, campo_nombre, campo_precio,
                      campo_caducidad, campo_stock, campo_minimo):
            campo.value = ""
        confirmacion.visible = False
        actualizar_tabla()

    def seleccionar(codigo):
        """Pasa los datos de la fila elegida a los campos del formulario."""
        nonlocal codigo_seleccionado
        p = inventario.buscar_por_codigo(codigo)
        if p is None:
            return
        codigo_seleccionado = codigo
        campo_codigo.value = p.codigo
        campo_nombre.value = p.nombre
        campo_precio.value = str(p.precio)
        campo_caducidad.value = p.caducidad
        campo_stock.value = str(p.stock)
        campo_minimo.value = str(p.stock_minimo)
        confirmacion.visible = False
        actualizar_tabla()

    # ---------- Acciones de los botones ----------
    def agregar_producto(e):
        try:
            inventario.agregar(leer_formulario())
            limpiar_formulario()
            mostrar_estado("Producto agregado.", VERDE)
        except (ValueError, RuntimeError) as error:
            mostrar_error(str(error))

    def actualizar_producto(e):
        if not codigo_seleccionado:
            mostrar_error("Selecciona un producto de la tabla.")
            return
        try:
            inventario.actualizar_por_codigo(codigo_seleccionado, leer_formulario())
            limpiar_formulario()
            mostrar_estado("Producto actualizado.", VERDE)
        except (ValueError, RuntimeError) as error:
            mostrar_error(str(error))

    def pedir_confirmacion_eliminar(e):
        """Botón Eliminar: primero muestra '¿Seguro?' antes de borrar."""
        if not codigo_seleccionado:
            mostrar_error("Selecciona un producto de la tabla.")
            return
        confirmacion.visible = True
        page.update()

    def confirmar_eliminar(e):
        try:
            inventario.eliminar_por_codigo(codigo_seleccionado)
            limpiar_formulario()
            mostrar_estado("Producto eliminado.", VERDE)
        except (ValueError, RuntimeError) as error:
            mostrar_error(str(error))

    def cancelar_eliminar(e):
        confirmacion.visible = False
        page.update()

    def leer_cantidad():
        """Lee el campo Cantidad: debe ser un entero mayor que cero."""
        try:
            cantidad = int((campo_cantidad.value or "").strip())
            if cantidad <= 0:
                raise ValueError
            return cantidad
        except ValueError:
            raise ValueError("La cantidad debe ser un número entero mayor que cero.")

    def vender_seleccionado(e):
        """Vende la cantidad indicada del producto seleccionado en la tabla."""
        if not codigo_seleccionado:
            mostrar_error("Selecciona un producto de la tabla.")
            return
        try:
            vendido = inventario.vender_por_codigo(codigo_seleccionado, leer_cantidad())
            limpiar_formulario()   # así el formulario no se queda con el stock viejo
            mostrar_estado(f"Vendido: {vendido.nombre} (quedan {vendido.stock})", VERDE)
        except (ValueError, RuntimeError) as error:
            mostrar_error(str(error))

    # ---------- Venta con escáner ----------
    def actualizar_venta_pendiente():
        """Muestra los artículos de la venta en curso."""
        if not venta_pendiente:
            texto_venta.value = "Sin artículos"
        else:
            partes = []
            for codigo, cantidad in venta_pendiente.items():
                p = inventario.buscar_por_codigo(codigo)
                nombre = p.nombre if p else codigo   # si no existe, mostramos el código
                partes.append(f"{nombre} x{cantidad}")
            texto_venta.value = ", ".join(partes)

    def agregar_a_venta(e):
        """Enter en el escáner o la cantidad: agrega un artículo a la venta pendiente."""
        codigo = (campo_escaner.value or "").strip()
        try:
            if not codigo:
                raise ValueError("Escribe o escanea un código.")
            cantidad = leer_cantidad()
            # si el código ya estaba, se suman las cantidades
            venta_pendiente[codigo] = venta_pendiente.get(codigo, 0) + cantidad
            actualizar_venta_pendiente()
            campo_escaner.value = ""
            mostrar_estado("Artículo agregado a la venta.", AZUL)
            enfocar(campo_escaner)
        except ValueError as error:
            mostrar_error(str(error))

    def finalizar_venta(e):
        if not venta_pendiente:
            mostrar_error("Agrega al menos un artículo a la venta.")
            return
        try:
            inventario.vender_por_codigos(venta_pendiente)
            total = sum(venta_pendiente.values())
            venta_pendiente.clear()
            actualizar_venta_pendiente()
            actualizar_tabla()
            mostrar_estado(f"Venta realizada: {total} artículos.", VERDE)
        except (ValueError, RuntimeError) as error:
            mostrar_error(str(error))

    # ---------- Mensaje de confirmación para eliminar (oculto al inicio) ----------
    confirmacion = ft.Row(
        [
            ft.Text("¿Eliminar el producto seleccionado?", weight=ft.FontWeight.BOLD),
            crear_boton("Sí, eliminar", ROJO, confirmar_eliminar),
            crear_boton("Cancelar", GRIS, cancelar_eliminar),
        ],
        visible=False,
    )

    # ---------- Armar la pantalla ----------
    titulo = ft.Container(
        content=ft.Column([
            ft.Text("Control de inventario", size=22, weight=ft.FontWeight.BOLD, color="#FFFFFF"),
            ft.Text("Mira de un vistazo qué se te está acabando", color="#BECDE6"),
        ], spacing=2),
        bgcolor=AZUL_OSCURO, padding=16,
    )

    barra_escaner = ft.Column([
        ft.Row([campo_escaner, campo_cantidad, campo_buscar], spacing=12),
        ft.Row([
            ft.Text("Artículos de esta venta:", weight=ft.FontWeight.BOLD),
            texto_venta,
            crear_boton("Finalizar venta", VERDE, finalizar_venta),
        ]),
    ])

    formulario = ft.Column([
        ft.Row(
            [campo_codigo, campo_nombre, campo_precio, campo_caducidad, campo_stock, campo_minimo],
            wrap=True, spacing=8,
        ),
        ft.Row([
            crear_boton("Agregar", VERDE, agregar_producto),
            crear_boton("Actualizar", AZUL, actualizar_producto),
            crear_boton("Vender cantidad", NARANJA, vender_seleccionado),
            crear_boton("Eliminar", ROJO, pedir_confirmacion_eliminar),
            crear_boton("Limpiar", GRIS, limpiar_formulario),
        ], wrap=True, spacing=8),
        confirmacion,
        etiqueta_estado,
    ])

    page.add(
        titulo,
        ft.Container(
            content=ft.Column([resumen, barra_escaner, encabezado, filas, formulario], spacing=10),
            padding=10,
        ),
    )
    actualizar_tabla()
    enfocar(campo_escaner)   # el cursor empieza en el campo del escáner


# ----------------------------------------------------------------------
# Punto de entrada
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Los datos se guardan en ~/.inventario/inventario.json
    # Si se pasa una ruta al ejecutar, se usa esa:  python inventario_flet.py mis_datos.json
    if len(sys.argv) > 1:
        ruta_datos = sys.argv[1]
    else:
        ruta_datos = os.path.join(os.path.expanduser("~"), ".inventario", "inventario.json")

    try:
        inventario_global = Inventario(ruta_datos)
    except RuntimeError as error:
        sys.stderr.write(f"{error}\n")   # mensaje de error en la consola
        sys.exit(1)                      # terminamos el programa con código de error

    def iniciar(page: ft.Page):
        main(page, inventario_global)

    # Flet 1.0 usa ft.run(); las versiones anteriores usan ft.app(target=...)
    if hasattr(ft, "run"):
        ft.run(iniciar)
    else:
        ft.app(target=iniciar)
