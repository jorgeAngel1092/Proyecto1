import flet as ft, os, sys, yaml, time
from src.clase.pagina import Pagina


def  main(Page: ft.Page):
    pagina = Pagina(Page, tamaño=(900, 650))
    Page.add(pagina.control)



if __name__ == "__main__":
    ft.run(main)