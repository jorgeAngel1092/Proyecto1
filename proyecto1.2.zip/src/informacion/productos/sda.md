---
codigo: '444'
nombre: sda
caducidad: hoy
precio: 100.0
stock: 140
stock_minimo: 1
proveedor: ''
---

