---
codigo: '555'
nombre: coca
caducidad: '2026-11-16'
precio: 15.0
stock: 50
stock_minimo: 10
proveedor: juan
---

