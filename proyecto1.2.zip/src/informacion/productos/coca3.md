---
codigo: '5556'
nombre: coca3
caducidad: '2026-11-19'
precio: 122.0
stock: 89
stock_minimo: 5
proveedor: juan
---

