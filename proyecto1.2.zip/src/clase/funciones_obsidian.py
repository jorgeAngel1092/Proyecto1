import os
from datetime import date, datetime

import yaml
 
CARPETA = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "informacion",
    "productos"
)
CARPETA_PROVEEDORES = os.path.join(
    os.path.dirname(CARPETA),
    "proveedores"
)
CARPETA_TURNOS = os.path.join(
    os.path.dirname(CARPETA),
    "turnos"
)
CARPETA_CORTES = os.path.join(
    os.path.dirname(CARPETA),
    "cortes"
)
CARPETA_REPORTES_CIERRE = os.path.join(
    os.path.dirname(CARPETA),
    "reportes_cierre"
)
CARPETA_APARTADOS = os.path.join(
    os.path.dirname(CARPETA),
    "apartados"
)

print("Ruta de archivos:", CARPETA)
os.makedirs(CARPETA, exist_ok=True)
os.makedirs(CARPETA_PROVEEDORES, exist_ok=True)
os.makedirs(CARPETA_TURNOS, exist_ok=True)
os.makedirs(CARPETA_CORTES, exist_ok=True)
os.makedirs(CARPETA_REPORTES_CIERRE, exist_ok=True)
os.makedirs(CARPETA_APARTADOS, exist_ok=True)

def ruta_nota(nombre):
    """Cada producto es un archivo 'nombre.md'."""
    return os.path.join(CARPETA, f"{nombre}.md")


def guardar_producto(datos, notas=""):
    """Crea o sobreescribe la nota de un producto ('datos' es un diccionario)."""
    datos = dict(datos)
    for campo in ("precio", "stock", "stock_minimo"):
        if campo in datos:
            try:
                valor = float(datos[campo])
            except (TypeError, ValueError) as error:
                raise ValueError(f"{campo.capitalize()} debe ser un número válido.") from error
            if valor < 0:
                raise ValueError(f"{campo.capitalize()} no puede ser negativo.")

    proveedor = datos.get("proveedor", "").strip()
    proveedor_datos = None

    if proveedor:
        proveedor_datos = buscar_proveedor(proveedor)

    if proveedor_datos:
        datos["proveedor"] = proveedor_datos["nombre"]
        productos = proveedor_datos.setdefault("productos", [])
        referencia = datos["nombre"]
        if referencia not in productos:
            productos.append(referencia)
        guardar_proveedor(proveedor_datos)

    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    with open(ruta_nota(datos["nombre"]), "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_texto}---\n{notas}\n")


def leer_producto(nombre):
    """Lee una nota y devuelve (datos, notas). Regresa None si no existe."""
    ruta = ruta_nota(nombre)
    if not os.path.exists(ruta):
        return None
    with open(ruta, "r", encoding="utf-8") as f:
        contenido = f.read()
    _, yaml_texto, notas = contenido.split("---", 2)   # separa: vacío | yaml | texto libre
    return yaml.safe_load(yaml_texto), notas.strip()


def leer_todos():
    """Devuelve una lista con los datos de todos los productos."""
    productos = []
    for archivo in sorted(os.listdir(CARPETA)):
        if archivo.endswith(".md"):
            datos, _ = leer_producto(archivo[:-3])
            productos.append(datos)
    return productos


def calcular_valor_inventario():
    """Calcula el valor actual del inventario como precio por stock."""
    total = 0.0
    for producto in leer_todos():
        if not producto:
            continue
        nombre = producto.get("nombre", "Producto sin nombre")
        try:
            precio = float(producto.get("precio", 0) or 0)
            stock = int(producto.get("stock", 0) or 0)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"Precio o stock no válido para {nombre}."
            ) from error
        if precio < 0 or stock < 0:
            raise ValueError(f"Precio o stock negativo para {nombre}.")
        total += precio * stock
    return round(total, 2)


def eliminar_producto(nombre):
    """Borra la nota del producto."""
    ruta = ruta_nota(nombre)
    if os.path.exists(ruta):
        os.remove(ruta)


def ruta_proveedor(nombre):
    """Devuelve la ruta de la nota de un proveedor."""
    return os.path.join(CARPETA_PROVEEDORES, f"{nombre}.md")


def guardar_proveedor(datos):
    """Crea o actualiza la nota de un proveedor."""
    datos = dict(datos)
    nombre = datos["nombre"].strip()
    if not nombre:
        raise ValueError("El nombre del proveedor es obligatorio.")

    datos.setdefault("productos", [])
    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    with open(ruta_proveedor(nombre), "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_texto}---\n")


def leer_proveedor(nombre):
    """Lee un proveedor por nombre. Regresa None si no existe."""
    ruta = ruta_proveedor(nombre)
    if not os.path.exists(ruta):
        return None

    with open(ruta, "r", encoding="utf-8") as f:
        contenido = f.read()

    _, yaml_texto, _ = contenido.split("---", 2)
    return yaml.safe_load(yaml_texto)


def leer_todos_proveedores():
    """Devuelve todos los proveedores guardados."""
    proveedores = []
    for archivo in sorted(os.listdir(CARPETA_PROVEEDORES)):
        if archivo.endswith(".md"):
            proveedor = leer_proveedor(archivo[:-3])
            if proveedor:
                proveedores.append(proveedor)
    return proveedores


def buscar_proveedor(valor):
    """Busca un proveedor por nombre."""
    valor = str(valor or "").strip().lower()
    if not valor:
        return None

    for proveedor in leer_todos_proveedores():
        if valor == str(proveedor.get("nombre", "")).lower():
            return proveedor
    return None


def buscar_productos(valor):
    """Busca productos por nombre o código, incluso por coincidencia parcial."""
    valor = str(valor or "").strip().lower()
    if not valor:
        return leer_todos()

    resultados = []
    for producto in leer_todos():
        if not producto:
            continue
        campos = (
            str(producto.get("nombre", "")),
            str(producto.get("codigo", "")),
        )
        if any(valor in campo.lower() for campo in campos):
            resultados.append(producto)
    return resultados


def verificar_alertas(dias_caducidad=30):
    """Devuelve alertas de caducidad y stock bajo con datos del proveedor."""
    hoy = date.today()
    alertas_caducidad = []
    alertas_stock = []

    for producto in leer_todos():
        if not producto:
            continue

        nombre = producto.get("nombre", "")
        proveedor_nombre = producto.get("proveedor", "")
        proveedor = buscar_proveedor(proveedor_nombre) if proveedor_nombre else None

        caducidad = producto.get("caducidad", "")
        if caducidad:
            try:
                fecha_caducidad = datetime.strptime(str(caducidad), "%Y-%m-%d").date()
                dias_restantes = (fecha_caducidad - hoy).days

                if dias_restantes <= dias_caducidad:
                    estado = "Caducado" if dias_restantes < 0 else "Próximo a caducar"
                    alertas_caducidad.append({
                        "producto": nombre,
                        "estado": estado,
                        "caducidad": str(caducidad),
                        "dias_restantes": dias_restantes,
                        "proveedor": proveedor,
                    })
            except (TypeError, ValueError):
                pass

        try:
            stock = int(producto.get("stock", 0) or 0)
            minimo = int(producto.get("stock_minimo", 0) or 0)
        except (TypeError, ValueError):
            stock = 0
            minimo = 0

        if stock <= minimo:
            alertas_stock.append({
                "producto": nombre,
                "stock": stock,
                "stock_minimo": minimo,
                "proveedor": proveedor,
            })

    return {
        "caducidad": alertas_caducidad,
        "stock": alertas_stock,
    }


def nombre_archivo_seguro(valor):
    """Convierte un texto en un nombre seguro para archivos."""
    reemplazos = ("/", "\\", ":", "*", "?", '"', "<", ">", "|")
    resultado = str(valor or "").strip()
    for caracter in reemplazos:
        resultado = resultado.replace(caracter, "-")
    return resultado or "Sin nombre"


def registrar_movimiento_turno(turno, datos):
    """Agrega un movimiento al turno y lo guarda en un archivo."""
    turno = nombre_archivo_seguro(turno)
    ruta = os.path.join(CARPETA_TURNOS, f"{turno}.md")
    contenido_actual = leer_turno(turno)

    movimiento = dict(datos)
    movimiento["fecha"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    contenido_actual["movimientos"].append(movimiento)

    yaml_texto = yaml.safe_dump(
        contenido_actual,
        allow_unicode=True,
        sort_keys=False,
    )
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_texto}---\n")
    return movimiento


def leer_turno(turno):
    """Lee los movimientos actuales de un turno."""
    turno = nombre_archivo_seguro(turno)
    ruta = os.path.join(CARPETA_TURNOS, f"{turno}.md")
    if not os.path.exists(ruta):
        return {
            "turno": turno,
            "movimientos": [],
        }

    with open(ruta, "r", encoding="utf-8") as f:
        contenido = f.read()
    try:
        _, yaml_texto, _ = contenido.split("---", 2)
        datos = yaml.safe_load(yaml_texto) or {}
    except ValueError:
        datos = {}
    datos.setdefault("turno", turno)
    datos.setdefault("movimientos", [])
    return datos


def crear_reporte_cierre_turno(
    turno,
    movimientos=None,
    fecha_cierre=None,
):
    """Crea y guarda un reporte Markdown con todos los movimientos del turno."""
    turno_seguro = nombre_archivo_seguro(turno)
    if movimientos is None:
        movimientos = leer_turno(turno_seguro).get("movimientos", [])
    else:
        movimientos = list(movimientos)

    fecha_cierre = fecha_cierre or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    marca_tiempo = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    ruta_reporte = os.path.join(
        CARPETA_REPORTES_CIERRE,
        f"{turno_seguro}_{marca_tiempo}.md",
    )

    lineas = [
        f"# Reporte de cierre - {turno_seguro}",
        "",
        f"- Fecha de cierre: {fecha_cierre}",
        f"- Total de movimientos: {len(movimientos)}",
        "",
        "## Detalle de movimientos",
        "",
    ]

    if movimientos:
        for indice, movimiento in enumerate(movimientos, start=1):
            lineas.extend([
                f"### Movimiento {indice}",
                "",
                "```yaml",
                yaml.safe_dump(
                    movimiento,
                    allow_unicode=True,
                    sort_keys=False,
                    default_flow_style=False,
                ).rstrip(),
                "```",
                "",
            ])
    else:
        lineas.append("No se registraron movimientos durante este turno.")

    with open(ruta_reporte, "w", encoding="utf-8") as f:
        f.write("\n".join(lineas) + "\n")

    return ruta_reporte


def guardar_corte_turno(turno):
    """Guarda el corte y reporte detallado del turno, y limpia sus movimientos."""
    turno_seguro = nombre_archivo_seguro(turno)
    datos_turno = leer_turno(turno_seguro)
    movimientos = list(datos_turno.get("movimientos", []))
    fecha_corte = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_reporte = crear_reporte_cierre_turno(
        turno_seguro,
        movimientos=movimientos,
        fecha_cierre=fecha_corte,
    )

    corte = {
        "turno": turno_seguro,
        "fecha": fecha_corte,
        "movimientos": movimientos,
        "reporte": ruta_reporte,
    }

    nombre_corte = (
        f"{turno_seguro}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
    )
    ruta = os.path.join(CARPETA_CORTES, f"{nombre_corte}.md")
    yaml_texto = yaml.safe_dump(
        corte,
        allow_unicode=True,
        sort_keys=False,
    )
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_texto}---\n")

    datos_turno["movimientos"] = []
    ruta_turno = os.path.join(CARPETA_TURNOS, f"{turno_seguro}.md")
    yaml_turno = yaml.safe_dump(
        datos_turno,
        allow_unicode=True,
        sort_keys=False,
    )
    with open(ruta_turno, "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_turno}---\n")

    return corte


def leer_cortes():
    """Devuelve todos los cortes guardados, del más reciente al más antiguo."""
    cortes = []
    for archivo in sorted(os.listdir(CARPETA_CORTES), reverse=True):
        if not archivo.endswith(".md"):
            continue
        ruta = os.path.join(CARPETA_CORTES, archivo)
        with open(ruta, "r", encoding="utf-8") as f:
            contenido = f.read()
        try:
            _, yaml_texto, _ = contenido.split("---", 2)
            corte = yaml.safe_load(yaml_texto) or {}
            if corte:
                cortes.append(corte)
        except ValueError:
            continue
    return cortes


def guardar_apartado(datos):
    """Guarda un producto apartado en su propio archivo."""
    datos = dict(datos)
    if not datos.get("producto"):
        raise ValueError("El producto es obligatorio.")
    if not datos.get("cliente"):
        raise ValueError("El nombre de quien aparta el producto es obligatorio.")

    apartado_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
    datos["fecha"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta = os.path.join(CARPETA_APARTADOS, f"{apartado_id}.md")
    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(f"---\n{yaml_texto}---\n")
    return apartado_id


def apartar_producto(valor_producto, cantidad, cliente, telefono=""):
    """Aparta una cantidad del inventario y registra el apartado."""
    consulta = str(valor_producto or "").strip().lower()
    if not consulta:
        raise ValueError("Selecciona un producto.")
    if not str(cliente or "").strip():
        raise ValueError("El nombre del cliente es obligatorio.")

    try:
        cantidad = int(cantidad)
    except (TypeError, ValueError) as error:
        raise ValueError("La cantidad debe ser un número entero.") from error
    if cantidad <= 0:
        raise ValueError("La cantidad debe ser mayor que cero.")

    coincidencias = buscar_productos(consulta)
    exactos = [
        producto for producto in coincidencias
        if consulta in (
            str(producto.get("nombre", "")).lower(),
            str(producto.get("codigo", "")).lower(),
        )
    ]
    if len(exactos) == 1:
        producto = exactos[0]
    elif len(exactos) > 1:
        raise ValueError("La búsqueda coincide con más de un producto.")
    elif len(coincidencias) == 1:
        producto = coincidencias[0]
    elif not coincidencias:
        raise ValueError("No se encontró el producto en el inventario.")
    else:
        raise ValueError("Hay varios productos coincidentes; selecciona uno de la lista.")

    try:
        stock_actual = int(producto.get("stock", 0) or 0)
    except (TypeError, ValueError) as error:
        raise ValueError("El stock del producto no es válido.") from error
    if stock_actual < 0:
        raise ValueError("El producto tiene un stock inválido.")
    if cantidad > stock_actual:
        raise ValueError(
            f"Stock insuficiente: hay {stock_actual} unidades disponibles."
        )

    stock_anterior = producto.get("stock", 0)
    producto["stock"] = stock_actual - cantidad
    guardar_producto(producto)
    try:
        apartado_id = guardar_apartado({
            "producto": producto.get("nombre", ""),
            "codigo": producto.get("codigo", ""),
            "cantidad": cantidad,
            "cliente": str(cliente).strip(),
            "telefono": str(telefono or "").strip(),
        })
    except OSError:
        producto["stock"] = stock_anterior
        guardar_producto(producto)
        raise

    return apartado_id, producto


def leer_apartados():
    """Devuelve los apartados guardados, del más reciente al más antiguo."""
    apartados = []
    for archivo in sorted(os.listdir(CARPETA_APARTADOS), reverse=True):
        if not archivo.endswith(".md"):
            continue
        ruta = os.path.join(CARPETA_APARTADOS, archivo)
        with open(ruta, "r", encoding="utf-8") as f:
            contenido = f.read()
        try:
            _, yaml_texto, _ = contenido.split("---", 2)
            apartado = yaml.safe_load(yaml_texto) or {}
            if apartado:
                apartado["_archivo"] = archivo[:-3]
                apartados.append(apartado)
        except ValueError:
            continue
    return apartados


def eliminar_apartado(apartado_id):
    """Elimina un apartado por su clave interna de archivo."""
    nombre = nombre_archivo_seguro(apartado_id)
    if nombre != apartado_id or not nombre:
        raise ValueError("Identificador de apartado no válido.")
    ruta = os.path.join(CARPETA_APARTADOS, f"{nombre}.md")
    if os.path.exists(ruta):
        os.remove(ruta)