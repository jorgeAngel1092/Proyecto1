package com.inventario;

import org.junit.jupiter.api.Test;           // marca un método como prueba
import org.junit.jupiter.api.io.TempDir;     // carpeta temporal para no tocar los datos reales

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

// Pruebas automáticas de lo más importante del inventario
class InventarioTest {

    @TempDir
    Path carpeta; // JUnit la crea y la borra sola

    // Crea una leche de prueba con el stock y el mínimo que le pidamos
    private Producto leche(int stock, int minimo) {
        return new Producto(0, "7501", "Leche", 32.5, LocalDate.now().plusDays(60), stock, minimo);
    }

    @Test
    void agregaActualizaYEliminaProductos() {
        Inventario inventario = new Inventario(carpeta.resolve("prueba.csv"));
        inventario.agregar(leche(8, 3));
        assertEquals(1, inventario.getProductos().get(0).getId()); // el primer id es 1

        // Un inventario nuevo que lee el mismo archivo debe ver el producto guardado
        Inventario otro = new Inventario(carpeta.resolve("prueba.csv"));
        assertEquals("Leche", otro.getProductos().get(0).getNombre());

        // Cambiamos el nombre y comprobamos que se actualizó
        inventario.actualizar(new Producto(1, "7501", "Leche entera", 35,
                LocalDate.now().plusDays(60), 5, 3));
        assertEquals("Leche entera", inventario.getProductos().get(0).getNombre());

        inventario.eliminar(1);
        assertEquals(0, inventario.getProductos().size());
    }

    @Test
    void rechazaStockNegativo() {
        Inventario inventario = new Inventario(carpeta.resolve("prueba.csv"));
        assertThrows(IllegalArgumentException.class, () -> inventario.agregar(leche(-1, 3)));
    }

    @Test
    void ventaPorCodigoDescuentaStockYNoDejaVenderSinStock() {
        Inventario inventario = new Inventario(carpeta.resolve("prueba.csv"));
        inventario.agregar(leche(2, 1));

        inventario.venderPorCodigo("7501");
        assertEquals(1, inventario.getProductos().get(0).getStock());

        inventario.venderPorCodigo("7501");
        assertEquals(0, inventario.getProductos().get(0).getStock());

        // Ya no queda stock, la tercera venta debe fallar
        assertThrows(IllegalArgumentException.class, () -> inventario.venderPorCodigo("7501"));
        // Un código que no existe también falla
        assertThrows(IllegalArgumentException.class, () -> inventario.venderPorCodigo("0000"));
    }

    @Test
    void ventaPorCodigoDescuentaLaCantidadSolicitada() {
        Inventario inventario = new Inventario(carpeta.resolve("cantidad.csv"));
        inventario.agregar(new Producto(0, "7502", "Pan", 15,
                LocalDate.now().plusDays(60), 5, 1));

        inventario.venderPorCodigo("7502", 3);

        assertEquals(2, inventario.getProductos().get(0).getStock());
        assertThrows(IllegalArgumentException.class,
                () -> inventario.venderPorCodigo("7502", 3));
    }

    @Test
    void ventaPuedeIncluirCodigosDiferentesSinVentaParcial() {
        Inventario inventario = new Inventario(carpeta.resolve("venta-conjunta.csv"));
        inventario.agregar(new Producto(0, "7502", "Pan", 15,
                LocalDate.now().plusDays(60), 5, 1));
        inventario.agregar(new Producto(0, "7503", "Leche", 32,
                LocalDate.now().plusDays(60), 4, 1));

        Map<String, Integer> venta = new LinkedHashMap<>();
        venta.put("7502", 2);
        venta.put("7503", 3);
        inventario.venderPorCodigos(venta);

        assertEquals(3, inventario.buscarPorCodigo("7502").getStock());
        assertEquals(1, inventario.buscarPorCodigo("7503").getStock());

        Map<String, Integer> ventaInvalida = new LinkedHashMap<>();
        ventaInvalida.put("7502", 1);
        ventaInvalida.put("7503", 2);
        assertThrows(IllegalArgumentException.class,
                () -> inventario.venderPorCodigos(ventaInvalida));
        assertEquals(3, inventario.buscarPorCodigo("7502").getStock());
    }

    @Test
    void alertasDeStockYCaducidad() {
        assertTrue(leche(5, 5).stockBajo());   // stock igual al mínimo: ya es bajo
        assertFalse(leche(6, 5).stockBajo());  // stock arriba del mínimo: está bien

        Producto vencido = new Producto(1, "1", "Pan", 15, LocalDate.now().minusDays(1), 20, 5);
        assertTrue(vencido.estaCaducado());
        assertEquals("CADUCADO", vencido.getAlerta());
    }

    @Test
    void quitaLasComasDelNombre() {
        Inventario inventario = new Inventario(carpeta.resolve("prueba.csv"));
        inventario.agregar(new Producto(0, "7503", "Pan, blanco", 15, LocalDate.now().plusDays(5), 10, 3));

        // Al volver a leer el archivo el producto debe seguir completo
        Inventario otro = new Inventario(carpeta.resolve("prueba.csv"));
        assertEquals("Pan blanco", otro.getProductos().get(0).getNombre());
    }
}
