package com.inventario; // Todas las clases del proyecto viven en este paquete

import java.time.LocalDate; // LocalDate guarda una fecha (año-mes-día) sin hora

// Un producto de la tienda.
// Esta clase solo guarda los datos y sabe decir si el producto tiene alguna alerta.
public class Producto {

    private long id;             // Número único del producto (1, 2, 3...)
    private String codigo;       // Código de barras o QR (puede ir vacío)
    private String nombre;       // Nombre del producto, por ejemplo "Leche"
    private double precio;       // Precio de venta
    private LocalDate caducidad; // Fecha en la que caduca
    private int stock;           // Cuántas piezas hay ahorita
    private int stockMinimo;     // Si hay esta cantidad o menos, avisamos que se está acabando

    // Constructor: se ejecuta cada vez que escribimos new Producto(...)
    public Producto(long id, String codigo, String nombre, double precio,
                    LocalDate caducidad, int stock, int stockMinimo) {
        this.id = id;                               // this.id es el atributo, id es el parámetro
        this.codigo = codigo.replace(",", "");      // quitamos las comas porque romperían el archivo CSV
        this.nombre = nombre.replace(",", "");      // lo mismo con el nombre
        this.precio = precio;                       // guardamos el precio
        this.caducidad = caducidad;                 // guardamos la fecha de caducidad
        this.stock = stock;                         // guardamos las piezas que hay
        this.stockMinimo = stockMinimo;             // guardamos el mínimo
    }

    // Getters: cada uno solo devuelve el dato que dice su nombre
    public long getId() { return id; }
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public LocalDate getCaducidad() { return caducidad; }
    public int getStock() { return stock; }
    public int getStockMinimo() { return stockMinimo; }

    // Setters: solo dos datos cambian después de crear el producto
    public void setId(long id) { this.id = id; }          // el inventario le pone el id al agregarlo
    public void setStock(int stock) { this.stock = stock; } // lo usamos al vender

    // ¿Ya pasó la fecha de caducidad?
    public boolean estaCaducado() {
        return caducidad.isBefore(LocalDate.now()); // true si la fecha es anterior a hoy
    }

    // ¿Caduca en los próximos 30 días? (si ya caducó no cuenta, eso es otra alerta)
    public boolean caducaPronto() {
        LocalDate limite = LocalDate.now().plusDays(30);        // hoy + 30 días
        return !estaCaducado() && !caducidad.isAfter(limite);   // no caducado y dentro del límite
    }

    // ¿Se está acabando? Es true cuando el stock llegó al mínimo o por debajo
    public boolean stockBajo() {
        return stock <= stockMinimo;
    }

    // Texto que se muestra en la columna "Alerta" (un producto puede tener dos alertas)
    public String getAlerta() {
        String alerta = "";                    // empezamos sin alerta
        if (estaCaducado()) {
            alerta = "CADUCADO";
        } else if (caducaPronto()) {
            alerta = "Caduca pronto";
        }
        if (stockBajo()) {
            if (!alerta.isEmpty()) {
                alerta = alerta + " + ";       // separamos las dos alertas con un +
            }
            alerta = alerta + "Stock bajo";
        }
        return alerta;                         // si no hay problemas, devuelve texto vacío
    }
}
