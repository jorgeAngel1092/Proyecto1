package com.inventario;

import java.awt.BorderLayout;                              // todos los componentes: botones, tabla, campos...
import java.awt.Color; // para pintar el encabezado de la tabla
import java.awt.Component;        // guarda los datos que se ven en la tabla
import java.awt.Dimension;        // para pintar las filas de colores
import java.awt.FlowLayout;                                 // colores, fuentes y layouts
import java.awt.Font;                  // para detectar cuando se escribe en el buscador
import java.awt.GridLayout;
import java.awt.LayoutManager;                         // ruta del archivo donde se guardan los datos
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;    // error si la fecha está mal escrita
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

// Ventana principal del programa: junta el resumen, el escáner, la tabla y el formulario.
public class InventarioApp extends JFrame {

    // Colores de la interfaz. Están aquí arriba para cambiarlos fácil.
    private static final Color AZUL_OSCURO = new Color(33, 53, 85);
    private static final Color VERDE = new Color(46, 160, 100);
    private static final Color AZUL = new Color(52, 120, 210);
    private static final Color ROJO = new Color(205, 65, 65);
    private static final Color NARANJA = new Color(235, 140, 40);
    private static final Color AMARILLO = new Color(200, 150, 10);
    private static final Color GRIS = new Color(120, 130, 140);
    private static final Color FONDO = new Color(245, 247, 250);

    private final Inventario inventario;      // la lógica: agregar, vender, guardar...
    private final DefaultTableModel modelo;   // los datos de la tabla
    private final JTable tabla;               // la tabla que vemos en pantalla
    private final DefaultTableModel modeloVenta;
    private final JTable tablaVenta;
    private final Map<String, Integer> ventaPendiente = new LinkedHashMap<>();

    // Campos de texto de arriba
    private final JTextField campoEscaner = new JTextField(); // aquí cae el código al escanear
    private final JTextField campoCantidad = new JTextField("1"); // piezas que se quieren vender
    private final JTextField campoBuscar = new JTextField();  // buscador por nombre o código

    // Campos del formulario de abajo
    private final JTextField campoCodigo = new JTextField();
    private final JTextField campoNombre = new JTextField();
    private final JTextField campoPrecio = new JTextField();
    private final JTextField campoCaducidad = new JTextField();
    private final JTextField campoStock = new JTextField();
    private final JTextField campoMinimo = new JTextField();

    // Números del resumen de arriba
    private final JLabel etiquetaCaducados = new JLabel("0");
    private final JLabel etiquetaPorCaducar = new JLabel("0");
    private final JLabel etiquetaStockBajo = new JLabel("0");
    private final JLabel etiquetaValor = new JLabel("$0.00");

    // Mensajito de abajo ("Vendido: Leche...")
    private final JLabel etiquetaEstado = new JLabel(" ");

    // Código del producto seleccionado en la tabla. Vacío significa que no hay ninguno.
    private String codigoSeleccionado = "";

    public InventarioApp() {
        super("Control de inventario"); // título de la ventana

        // Los datos se guardan en la carpeta del usuario: ~/.inventario/inventario.csv
        inventario = new Inventario(Path.of(
                System.getProperty("user.home"), ".inventario", "inventario.csv"));

        // Columnas de la tabla. Las celdas no se pueden editar directo (se edita con el formulario).
        modelo = new DefaultTableModel(new Object[]{
                "Código", "Nombre", "Precio", "Caducidad", "Stock", "Mínimo", "Alerta"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = crearTabla();
        modeloVenta = new DefaultTableModel(new Object[]{"Código", "Cantidad"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaVenta = crearTablaVenta();

        configurarVentana();
        agregarPartes();
        actualizarTabla();

        // Cuando el usuario elige una fila, pasamos sus datos al formulario
        tabla.getSelectionModel().addListSelectionListener(evento -> {
            if (!evento.getValueIsAdjusting()) {
                cargarProductoSeleccionado();
            }
        });
    }

    // ---------- Armar la ventana ----------

    // Tamaño y comportamiento básico de la ventana
    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // al cerrar la ventana se termina el programa
        setSize(1050, 720);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);                    // la centra en la pantalla
        getContentPane().setBackground(FONDO);
        setLayout(new BorderLayout(0, 8));              // arriba, centro y abajo
    }

    // Pone cada parte en su lugar
    private void agregarPartes() {
        add(crearParteSuperior(), BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(crearFormulario(), BorderLayout.SOUTH);
    }

    // Crea la tabla. Cada fila se pinta según su alerta.
    private JTable crearTabla() {
        JTable nueva = new JTable(modelo) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int fila, int columna) {
                Component celda = super.prepareRenderer(renderer, fila, columna);
                String alerta = modelo.getValueAt(fila, 6).toString(); // columna 6 = Alerta
                if (isRowSelected(fila)) {
                    celda.setBackground(new Color(160, 195, 240));     // azul: fila seleccionada
                } else if (alerta.contains("CADUCADO")) {
                    celda.setBackground(new Color(250, 210, 210));     // rojo claro
                } else if (alerta.contains("Caduca pronto")) {
                    celda.setBackground(new Color(255, 230, 195));     // naranja claro
                } else if (alerta.contains("Stock bajo")) {
                    celda.setBackground(new Color(255, 246, 190));     // amarillo claro
                } else {
                    celda.setBackground(Color.WHITE);                  // sin alerta
                }
                celda.setForeground(Color.BLACK);
                return celda;
            }
        };
        nueva.setRowHeight(26);
        nueva.setFont(new Font("SansSerif", Font.PLAIN, 14));
        nueva.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // solo una fila a la vez
        nueva.setGridColor(new Color(225, 228, 235));

        // Encabezado azul oscuro con letras blancas
        DefaultTableCellRenderer cabecera = new DefaultTableCellRenderer();
        cabecera.setBackground(AZUL_OSCURO);
        cabecera.setForeground(Color.WHITE);
        cabecera.setHorizontalAlignment(SwingConstants.CENTER);
        nueva.getTableHeader().setDefaultRenderer(cabecera);
        nueva.getTableHeader().setPreferredSize(new Dimension(100, 30));

        // Anchos de algunas columnas
        nueva.getColumnModel().getColumn(0).setPreferredWidth(140);  // Código
        nueva.getColumnModel().getColumn(1).setPreferredWidth(200);  // Nombre
        nueva.getColumnModel().getColumn(6).setPreferredWidth(200);  // Alerta
        return nueva;
    }

    // Parte de arriba: título, resumen y escáner, una debajo de otra
    private JPanel crearParteSuperior() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(crearTitulo());
        panel.add(crearResumen());
        panel.add(crearBarraEscaner());
        return panel;
    }

    // Barra azul con el nombre del programa
    private JPanel crearTitulo() {
        JPanel panel = new JPanel(new GridLayout(2, 1));
        panel.setBackground(AZUL_OSCURO);
        panel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JLabel titulo = new JLabel("Control de inventario");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);

        JLabel subtitulo = new JLabel("Mira de un vistazo qué se te está acabando");
        subtitulo.setForeground(new Color(190, 205, 230));

        panel.add(titulo);
        panel.add(subtitulo);
        return panel;
    }

    // Las cuatro tarjetas de colores con los números
    private JPanel crearResumen() {
        JPanel panel = panelConFondo(new GridLayout(1, 4, 10, 0));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 4, 10));
        panel.add(crearTarjeta("Caducados", etiquetaCaducados, ROJO));
        panel.add(crearTarjeta("Caducan en 30 días", etiquetaPorCaducar, NARANJA));
        panel.add(crearTarjeta("Stock bajo", etiquetaStockBajo, AMARILLO));
        panel.add(crearTarjeta("Valor del inventario", etiquetaValor, VERDE));
        return panel;
    }

    // Una tarjeta: un título chiquito y el número grande
    private JPanel crearTarjeta(String titulo, JLabel numero, Color color) {
        JPanel tarjeta = new JPanel(new GridLayout(2, 1));
        tarjeta.setBackground(color);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));

        JLabel textoTitulo = new JLabel(titulo);
        textoTitulo.setForeground(Color.WHITE);

        numero.setForeground(Color.WHITE);
        numero.setFont(new Font("SansSerif", Font.BOLD, 26));

        tarjeta.add(textoTitulo);
        tarjeta.add(numero);
        return tarjeta;
    }

    // Fila con el campo del escáner (vende al dar Enter) y el buscador
    private JPanel crearBarraEscaner() {
        JPanel panel = panelConFondo(new BorderLayout(8, 6));
        panel.setBorder(BorderFactory.createEmptyBorder(6, 10, 4, 10));
        JPanel controles = panelConFondo(new GridLayout(1, 3, 12, 0));

        // El lector de código de barras escribe el código y presiona Enter solo.
        campoEscaner.setFont(new Font("SansSerif", Font.PLAIN, 15));
        campoEscaner.setBorder(BorderFactory.createLineBorder(VERDE, 2));
        campoEscaner.addActionListener(evento -> venderPorEscaner());

        campoCantidad.setFont(new Font("SansSerif", Font.PLAIN, 15));
        campoCantidad.setHorizontalAlignment(SwingConstants.CENTER);
        campoCantidad.addActionListener(evento -> venderPorEscaner());

        // Cada vez que se suelta una tecla en el buscador, se vuelve a filtrar la tabla
        campoBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent evento) {
                actualizarTabla();
            }
        });

        controles.add(campoConTitulo("Escanear código:", campoEscaner));
        controles.add(campoConTitulo("Cantidad:", campoCantidad));
        controles.add(campoConTitulo("Buscar:", campoBuscar));

        JPanel venta = panelConFondo(new BorderLayout(8, 0));
        venta.add(new JLabel("Artículos de esta venta:"), BorderLayout.WEST);
        venta.add(new JScrollPane(tablaVenta), BorderLayout.CENTER);
        JButton finalizar = crearBoton("Finalizar venta", VERDE);
        finalizar.addActionListener(evento -> finalizarVenta());
        venta.add(finalizar, BorderLayout.EAST);

        panel.add(controles, BorderLayout.NORTH);
        panel.add(venta, BorderLayout.CENTER);
        return panel;
    }

    private JTable crearTablaVenta() {
        JTable nueva = new JTable(modeloVenta);
        nueva.setRowHeight(22);
        nueva.setPreferredScrollableViewportSize(new Dimension(180, 45));
        nueva.getColumnModel().getColumn(0).setPreferredWidth(120);
        nueva.getColumnModel().getColumn(1).setPreferredWidth(70);
        return nueva;
    }

    // Un texto a la izquierda y un campo a la derecha
    private JPanel campoConTitulo(String titulo, JTextField campo) {
        JPanel panel = panelConFondo(new BorderLayout(8, 0));
        panel.add(new JLabel(titulo), BorderLayout.WEST);
        panel.add(campo, BorderLayout.CENTER);
        return panel;
    }

    // Parte de abajo: campos, botones y mensaje de estado
    private JPanel crearFormulario() {
        JPanel panel = panelConFondo(new BorderLayout(0, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        // Dos filas: los títulos y debajo los campos
        JPanel campos = panelConFondo(new GridLayout(2, 6, 8, 4));
        campos.add(new JLabel("Código"));
        campos.add(new JLabel("Nombre"));
        campos.add(new JLabel("Precio"));
        campos.add(new JLabel("Caducidad (AAAA-MM-DD)"));
        campos.add(new JLabel("Stock"));
        campos.add(new JLabel("Stock mínimo"));
        campos.add(campoCodigo);
        campos.add(campoNombre);
        campos.add(campoPrecio);
        campos.add(campoCaducidad);
        campos.add(campoStock);
        campos.add(campoMinimo);

        // Botones de colores
        JPanel botones = panelConFondo(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JButton agregar = crearBoton("Agregar", VERDE);
        JButton actualizar = crearBoton("Actualizar", AZUL);
        JButton vender = crearBoton("Vender cantidad", NARANJA);
        JButton eliminar = crearBoton("Eliminar", ROJO);
        JButton limpiar = crearBoton("Limpiar", GRIS);

        // Qué hace cada botón al hacerle clic
        agregar.addActionListener(evento -> agregarProducto());
        actualizar.addActionListener(evento -> actualizarProducto());
        vender.addActionListener(evento -> venderSeleccionado());
        eliminar.addActionListener(evento -> eliminarProducto());
        limpiar.addActionListener(evento -> limpiarFormulario());

        botones.add(agregar);
        botones.add(actualizar);
        botones.add(vender);
        botones.add(eliminar);
        botones.add(limpiar);

        etiquetaEstado.setFont(new Font("SansSerif", Font.BOLD, 14));

        panel.add(campos, BorderLayout.NORTH);
        panel.add(botones, BorderLayout.CENTER);
        panel.add(etiquetaEstado, BorderLayout.SOUTH);
        return panel;
    }

    // Crea un botón con color de fondo y letras blancas
    private JButton crearBoton(String texto, Color color) {
        JButton boton = new JButton(texto);
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("SansSerif", Font.BOLD, 13));
        boton.setOpaque(true);          // sin esto el color no se ve en algunas computadoras (Mac)
        boton.setBorderPainted(false);  // sin borde para que se vea todo el color
        boton.setFocusPainted(false);   // sin el recuadrito punteado al hacer clic
        boton.setPreferredSize(new Dimension(120, 34));
        return boton;
    }

    // Un panel normal pero con el color de fondo de la app
    private JPanel panelConFondo(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(FONDO);
        return panel;
    }

    // ---------- Acciones de los botones ----------

    // Botón Agregar: lee el formulario y guarda un producto nuevo
    private void agregarProducto() {
        try {
            inventario.agregar(leerFormulario());
            limpiarFormulario();
            actualizarTabla();
            mostrarEstado("Producto agregado.", VERDE);
        } catch (RuntimeException error) {   // atrapa los errores que lanzamos (datos mal escritos)
            mostrarError(error.getMessage());
        }
    }

    // Botón Actualizar: guarda los cambios del producto seleccionado
    private void actualizarProducto() {
        if (codigoSeleccionado.isEmpty()) {
            mostrarError("Selecciona un producto de la tabla.");
            return;
        }
        try {
            Producto datos = leerFormulario();
            datos = inventario.actualizarPorCodigo(codigoSeleccionado, datos);
            limpiarFormulario();
            actualizarTabla();
            mostrarEstado("Producto actualizado.", VERDE);
        } catch (RuntimeException error) {
            mostrarError(error.getMessage());
        }
    }

    // Botón Eliminar: pregunta antes de borrar
    private void eliminarProducto() {
        if (codigoSeleccionado.isEmpty()) {
            mostrarError("Selecciona un producto de la tabla.");
            return;
        }
        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el producto seleccionado?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            try {
                inventario.eliminarPorCodigo(codigoSeleccionado);
                limpiarFormulario();
                actualizarTabla();
                mostrarEstado("Producto eliminado.", VERDE);
            } catch (RuntimeException error) {
                mostrarError(error.getMessage());
            }
        }
    }

    // Botón de venta: vende la cantidad indicada del producto seleccionado
    private void venderSeleccionado() {
        if (codigoSeleccionado.isEmpty()) {
            mostrarError("Selecciona un producto de la tabla.");
            return;
        }
        try {
            mostrarVenta(inventario.venderPorCodigo(codigoSeleccionado, leerCantidad()));
        } catch (RuntimeException error) {
            mostrarEstado(error.getMessage(), ROJO);
        }
    }

    // Enter en el escáner o la cantidad: agrega un artículo a la venta pendiente
    private void venderPorEscaner() {
        String codigo = campoEscaner.getText().trim();
        try {
            if (codigo.isEmpty()) {
                throw new IllegalArgumentException("Escribe o escanea un código.");
            }
            int cantidad = leerCantidad();
            ventaPendiente.merge(codigo, cantidad, Integer::sum);
            actualizarVentaPendiente();
            campoEscaner.setText("");
            campoEscaner.requestFocusInWindow();
            mostrarEstado("Artículo agregado a la venta.", AZUL);
        } catch (RuntimeException error) {
            mostrarEstado(error.getMessage(), ROJO);
        }
    }

    private void finalizarVenta() {
        if (ventaPendiente.isEmpty()) {
            mostrarError("Agrega al menos un artículo a la venta.");
            return;
        }
        try {
            inventario.venderPorCodigos(ventaPendiente);
            int totalArticulos = ventaPendiente.values().stream().mapToInt(Integer::intValue).sum();
            ventaPendiente.clear();
            actualizarVentaPendiente();
            actualizarTabla();
            mostrarEstado("Venta realizada: " + totalArticulos + " artículos.", VERDE);
        } catch (RuntimeException error) {
            mostrarEstado(error.getMessage(), ROJO);
        }
    }

    private void actualizarVentaPendiente() {
        modeloVenta.setRowCount(0);
        for (Map.Entry<String, Integer> articulo : ventaPendiente.entrySet()) {
            modeloVenta.addRow(new Object[]{articulo.getKey(), articulo.getValue()});
        }
    }

    private int leerCantidad() {
        try {
            int cantidad = Integer.parseInt(campoCantidad.getText().trim());
            if (cantidad <= 0) {
                throw new NumberFormatException();
            }
            return cantidad;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("La cantidad debe ser un número entero mayor que cero.");
        }
    }

    // Lo que se hace después de cualquier venta
    private void mostrarVenta(Producto vendido) {
        limpiarFormulario();   // así el formulario no se queda con el stock viejo
        actualizarTabla();
        mostrarEstado("Vendido: " + vendido.getNombre() + " (quedan " + vendido.getStock() + ")", VERDE);
    }

    // ---------- Formulario y tabla ----------

    // Convierte lo que escribió el usuario en un Producto
    private Producto leerFormulario() {
        String codigo = campoCodigo.getText().trim();
        String nombre = campoNombre.getText().trim();

        double precio;
        try {
            // cambiamos coma por punto por si escriben 25,50
            precio = Double.parseDouble(campoPrecio.getText().trim().replace(",", "."));
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("El precio debe ser un número, por ejemplo 25.50");
        }

        LocalDate caducidad;
        try {
            caducidad = LocalDate.parse(campoCaducidad.getText().trim());
        } catch (DateTimeParseException error) {
            throw new IllegalArgumentException("La fecha debe ser AAAA-MM-DD, por ejemplo 2027-03-15");
        }

        int stock;
        try {
            stock = Integer.parseInt(campoStock.getText().trim());
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("El stock debe ser un número entero.");
        }

        int minimo = 10; // si dejan el mínimo vacío usamos 10
        String textoMinimo = campoMinimo.getText().trim();
        if (!textoMinimo.isEmpty()) {
            try {
                minimo = Integer.parseInt(textoMinimo);
            } catch (NumberFormatException error) {
                throw new IllegalArgumentException("El stock mínimo debe ser un número entero.");
            }
        }

        return new Producto(0, codigo, nombre, precio, caducidad, stock, minimo);
    }

    // Pasa los datos de la fila seleccionada a los campos del formulario
    private void cargarProductoSeleccionado() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            return; // no hay fila seleccionada
        }
        codigoSeleccionado = (String) modelo.getValueAt(fila, 0);
        Producto p = inventario.buscarPorCodigo(codigoSeleccionado);
        campoCodigo.setText(p.getCodigo());
        campoNombre.setText(p.getNombre());
        campoPrecio.setText(String.valueOf(p.getPrecio()));
        campoCaducidad.setText(p.getCaducidad().toString());
        campoStock.setText(String.valueOf(p.getStock()));
        campoMinimo.setText(String.valueOf(p.getStockMinimo()));
    }

    // Vacía el formulario y quita la selección
    private void limpiarFormulario() {
        codigoSeleccionado = "";
        tabla.clearSelection();
        campoCodigo.setText("");
        campoNombre.setText("");
        campoPrecio.setText("");
        campoCaducidad.setText("");
        campoStock.setText("");
        campoMinimo.setText("");
    }

    // Vuelve a llenar la tabla (con el filtro del buscador) y actualiza los números de arriba
    private void actualizarTabla() {
        modelo.setRowCount(0); // borra todas las filas
        String texto = campoBuscar.getText().trim().toLowerCase();

        for (Producto p : inventario.getProductos()) {
            boolean coincide = texto.isEmpty()
                    || p.getNombre().toLowerCase().contains(texto)
                    || p.getCodigo().toLowerCase().contains(texto);
            if (coincide) {
                modelo.addRow(new Object[]{
                        p.getCodigo(), p.getNombre(),
                        String.format("%.2f", p.getPrecio()),
                        p.getCaducidad(), p.getStock(), p.getStockMinimo(), p.getAlerta()});
            }
        }

        // Números del resumen (cuentan todos los productos, aunque el buscador filtre)
        etiquetaCaducados.setText(String.valueOf(inventario.contarCaducados()));
        etiquetaPorCaducar.setText(String.valueOf(inventario.contarPorCaducar()));
        etiquetaStockBajo.setText(String.valueOf(inventario.contarStockBajo()));
        etiquetaValor.setText("$" + String.format("%.2f", inventario.valorTotal()));
    }

    // ---------- Mensajes ----------

    // Ventana emergente de error
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Mensaje de color en la parte de abajo de la ventana
    private void mostrarEstado(String mensaje, Color color) {
        etiquetaEstado.setText(mensaje);
        etiquetaEstado.setForeground(color);
    }

       public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InventarioApp ventana = new InventarioApp();
            ventana.setVisible(true);
            ventana.campoEscaner.requestFocusInWindow(); // el cursor empieza en el campo del escáner
        });
    }
}
