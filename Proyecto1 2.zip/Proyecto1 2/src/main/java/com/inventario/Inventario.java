package com.inventario;

import java.io.IOException;                  // error que puede pasar al leer o escribir archivos
import java.nio.charset.StandardCharsets;    // para guardar bien los acentos (UTF-8)
import java.nio.file.Files;                  // leer y escribir archivos
import java.nio.file.Path;                   // representa la ruta de un archivo
import java.time.LocalDate;                  // fechas
import java.util.ArrayList;                  // lista que crece sola
import java.util.Map;
import java.util.List;                       // tipo "lista"

// Aquí está toda la lógica: agregar, editar, eliminar y vender productos.
// Los datos se guardan en un archivo CSV (texto con los datos separados por comas).
public class Inventario {

    private final Path archivo;                                   // dónde se guarda el CSV
    private final List<Producto> productos = new ArrayList<>();   // los productos, en memoria

    // Constructor: recibe la ruta del archivo y carga lo que ya estaba guardado
    public Inventario(Path archivo) {
        this.archivo = archivo;
        cargar();
    }

    // Devuelve la lista completa de productos
    public List<Producto> getProductos() {
        return productos;
    }

    // ---------- Agregar, editar y eliminar ----------

    // Agrega un producto nuevo y le asigna su id
    public void agregar(Producto producto) {
        validar(producto);                    // si algo está mal, aquí se lanza el error
        producto.setId(siguienteId());        // id nuevo = el id más grande + 1
        productos.add(producto);              // lo metemos a la lista
        guardar();                            // y guardamos el archivo
    }

    // Cambia los datos del producto que tenga el mismo id
    public void actualizar(Producto producto) {
        validar(producto);
        Producto viejo = buscarPorId(producto.getId());   // buscamos el producto anterior
        if (viejo == null) {
            throw new IllegalArgumentException("El producto no existe.");
        }
        productos.set(productos.indexOf(viejo), producto); // reemplazamos el viejo por el nuevo
        guardar();
    }

    // Borra el producto con ese id
    public void eliminar(long id) {
        Producto producto = buscarPorId(id);
        if (producto == null) {
            throw new IllegalArgumentException("El producto no existe.");
        }
        productos.remove(producto);
        guardar();
    }

    // ---------- Ventas ----------

    // Vende una pieza del producto: le resta 1 al stock
    public Producto vender(long id) {
        Producto producto = buscarPorId(id);
        if (producto == null) {
            throw new IllegalArgumentException("El producto no existe.");
        }
        if (producto.getStock() <= 0) {       // no se puede vender lo que no hay
            throw new IllegalArgumentException("No queda stock de " + producto.getNombre() + ".");
        }
        producto.setStock(producto.getStock() - 1);   // restamos una pieza
        guardar();
        return producto;
    }

    // Igual que vender, pero buscando el producto por su código de barras / QR
    public Producto venderPorCodigo(String codigo) {
        return venderPorCodigo(codigo, 1);
    }

    public Producto venderPorCodigo(String codigo, int cantidad) {
        Producto producto = buscarPorCodigo(codigo);
        if (producto == null) {
            throw new IllegalArgumentException("No hay ningún producto con el código " + codigo);
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
        }
        if (producto.getStock() < cantidad) {
            throw new IllegalArgumentException("No hay suficiente stock de " + producto.getNombre() + ".");
        }
        producto.setStock(producto.getStock() - cantidad);
        guardar();
        return producto;
    }

    public void venderPorCodigos(Map<String, Integer> cantidades) {
        if (cantidades.isEmpty()) {
            throw new IllegalArgumentException("La venta no tiene artículos.");
        }
        for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
            Producto producto = buscarPorCodigo(entrada.getKey());
            int cantidad = entrada.getValue();
            if (producto == null) {
                throw new IllegalArgumentException("No hay ningún producto con el código " + entrada.getKey());
            }
            if (cantidad <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor que cero.");
            }
            if (producto.getStock() < cantidad) {
                throw new IllegalArgumentException("No hay suficiente stock de " + producto.getNombre() + ".");
            }
        }
        for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
            Producto producto = buscarPorCodigo(entrada.getKey());
            producto.setStock(producto.getStock() - entrada.getValue());
        }
        guardar();
    }

    public Producto actualizarPorCodigo(String codigo, Producto datos) {
        Producto viejo = buscarPorCodigo(codigo);
        if (viejo == null) {
            throw new IllegalArgumentException("El producto no existe.");
        }
        datos.setId(viejo.getId());
        actualizar(datos);
        return datos;
    }

    public void eliminarPorCodigo(String codigo) {
        Producto producto = buscarPorCodigo(codigo);
        if (producto == null) {
            throw new IllegalArgumentException("El producto no existe.");
        }
        eliminar(producto.getId());
    }

    // ---------- Búsquedas ----------

    // Regresa el producto con ese id, o null si no existe
    public Producto buscarPorId(long id) {
        for (Producto p : productos) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    // Regresa el producto con ese código, o null si no existe
    public Producto buscarPorCodigo(String codigo) {
        for (Producto p : productos) {
            if (!p.getCodigo().isEmpty() && p.getCodigo().equals(codigo)) {
                return p;
            }
        }
        return null;
    }

    // ---------- Números para el resumen de arriba ----------

    // Cuántos productos ya caducaron
    public int contarCaducados() {
        int total = 0;
        for (Producto p : productos) {
            if (p.estaCaducado()) {
                total++;
            }
        }
        return total;
    }

    // Cuántos caducan en los próximos 30 días
    public int contarPorCaducar() {
        int total = 0;
        for (Producto p : productos) {
            if (p.caducaPronto()) {
                total++;
            }
        }
        return total;
    }

    // Cuántos tienen el stock en el mínimo o por debajo
    public int contarStockBajo() {
        int total = 0;
        for (Producto p : productos) {
            if (p.stockBajo()) {
                total++;
            }
        }
        return total;
    }

    // Cuánto dinero hay en mercancía (precio x piezas de cada producto)
    public double valorTotal() {
        double total = 0;
        for (Producto p : productos) {
            total = total + p.getPrecio() * p.getStock();
        }
        return total;
    }

    // ---------- Cosas internas ----------

    // Revisa que los datos tengan sentido antes de guardarlos
    private void validar(Producto p) {
        if (p.getNombre().trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio.");
        }
        if (p.getPrecio() < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        if (p.getCaducidad() == null) {
            throw new IllegalArgumentException("La caducidad es obligatoria.");
        }
        if (p.getStock() < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }
        if (p.getStockMinimo() < 0) {
            throw new IllegalArgumentException("El stock mínimo no puede ser negativo.");
        }
        if (p.getCodigo().trim().isEmpty()) {
            throw new IllegalArgumentException("El código es obligatorio.");
        }
        // Dos productos no pueden tener el mismo código
        for (Producto otro : productos) {
            boolean mismoCodigo = otro.getCodigo().equals(p.getCodigo());
            if (mismoCodigo && otro.getId() != p.getId()) {
                throw new IllegalArgumentException("Ya existe un producto con ese código.");
            }
        }
    }

    // Busca el id más grande que hay y le suma 1
    private long siguienteId() {
        long mayor = 0;
        for (Producto p : productos) {
            if (p.getId() > mayor) {
                mayor = p.getId();
            }
        }
        return mayor + 1;
    }

    // Lee el archivo CSV y llena la lista de productos
    private void cargar() {
        if (!Files.exists(archivo)) {
            return; // primera vez que se usa: no hay archivo, empezamos con la lista vacía
        }
        try {
            List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
            for (int i = 1; i < lineas.size(); i++) {       // empezamos en 1 porque la línea 0 trae los títulos
                String[] datos = lineas.get(i).split(",");  // separamos la línea por comas
                if (datos.length != 7) {
                    continue;                                // línea vacía o rara, la saltamos
                }
                try {
                    productos.add(new Producto(
                            Long.parseLong(datos[0]),        // id
                            datos[1],                        // código
                            datos[2],                        // nombre
                            Double.parseDouble(datos[3]),    // precio
                            LocalDate.parse(datos[4]),       // caducidad
                            Integer.parseInt(datos[5]),      // stock
                            Integer.parseInt(datos[6])));    // stock mínimo
                } catch (RuntimeException error) {
                    // si una línea está dañada la ignoramos para que el programa no se caiga
                }
            }
        } catch (IOException error) {
            throw new IllegalStateException("No se pudo leer el inventario: " + error.getMessage());
        }
    }

    // Escribe todos los productos en el archivo CSV
    private void guardar() {
        List<String> lineas = new ArrayList<>();
        lineas.add("id,codigo,nombre,precio,caducidad,stock,minimo"); // primera línea: títulos
        for (Producto p : productos) {
            lineas.add(p.getId() + "," + p.getCodigo() + "," + p.getNombre() + ","
                    + p.getPrecio() + "," + p.getCaducidad() + ","
                    + p.getStock() + "," + p.getStockMinimo());
        }
        try {
            Files.createDirectories(archivo.toAbsolutePath().getParent()); // crea la carpeta si no existe
            Files.write(archivo, lineas, StandardCharsets.UTF_8);           // escribe el archivo
        } catch (IOException error) {
            throw new IllegalStateException("No se pudo guardar el inventario: " + error.getMessage());
        }
    }
}
