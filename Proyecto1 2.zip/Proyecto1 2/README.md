# Control de inventario para pequeños negocios

Programa de escritorio en Java (Swing) para que un negocio pequeño vea de un vistazo qué se le está acabando.

## Qué hace

- Agregar, editar y eliminar productos (nombre, código, precio, caducidad, stock y stock mínimo).
- Alertas de color en la tabla: rojo si ya caducó, naranja si caduca en 30 días, amarillo si el stock llegó al mínimo.
- Resumen arriba con caducados, próximos a caducar, stock bajo y valor del inventario.
- Botón "Vender 1" y campo de escáner: al escanear un código de barras o QR se vende una pieza.
- Buscador por nombre o código.
- Los datos se guardan en `~/.inventario/inventario.csv`.

## Cómo ejecutarlo

Con Java 17 o más reciente:

1. Abrir la carpeta en VS Code o IntelliJ y ejecutar `InventarioApp.java`.
2. O con Maven: `mvn package` y luego `java -jar target/control-inventario-1.0.0.jar`.

Para probar con datos de ejemplo, copiar `datos-demo.csv` a `~/.inventario/inventario.csv` (crear la carpeta si no existe).

## Escáner

Un lector USB de código de barras funciona como un teclado: escribe el código y presiona Enter. Basta con tener el cursor en el campo verde "Escanear código". También se puede escribir el código a mano y dar Enter.

## Pruebas

`mvn test`
