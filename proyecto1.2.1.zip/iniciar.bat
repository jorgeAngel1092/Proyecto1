@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo No se encontro Python. Instalalo y agregalo al PATH.
    pause
    exit /b 1
)

if not exist "VENV\Scripts\python.exe" (
    echo Creando el entorno virtual VENV...
    python -m venv VENV
    if errorlevel 1 goto setup_error

    call "VENV\Scripts\activate.bat"
    if errorlevel 1 goto setup_error
) else (
    call "VENV\Scripts\activate.bat"
    if errorlevel 1 goto activation_error
)

echo Comprobando los requisitos...
python -m pip install -r "requerimientos.txt"
if errorlevel 1 goto setup_error

echo Iniciando la aplicacion...
python app.py
if errorlevel 1 goto app_error
exit /b 0

:setup_error
echo No se pudo crear el entorno o instalar los requisitos.
pause
exit /b 1

:activation_error
echo No se pudo activar el entorno virtual VENV.
pause
exit /b 1

:app_error
echo La aplicacion termino con un error.
pause
exit /b 1
