import flet as ft, os, sys, yaml, time
from src.clase.funciones_obsidian import migrar_datos_locales_a_obsidian
from src.clase.obsidian_api import ObsidianAPIError
from src.clase.pagina import Pagina


def  main(Page: ft.Page):
    try:
        migrar_datos_locales_a_obsidian()
    except ObsidianAPIError as error:
        Page.title = "Conexión con Obsidian"
        Page.bgcolor = "#020617"
        Page.add(
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(
                            "No se pudo conectar con Obsidian",
                            size=24,
                            weight=ft.FontWeight.BOLD,
                            color="#F8FAFC",
                        ),
                        ft.Text(str(error), color="#FCA5A5"),
                        ft.Text(
                            "Revisa que Obsidian y Local REST API estén activos, "
                            "y que variables.json tenga la configuración correcta.",
                            color="#CBD5E1",
                        ),
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=12,
                ),
                bgcolor="#1E293B",
                padding=24,
                border_radius=6,
                alignment=ft.Alignment.CENTER,
            )
        )
        return

    pagina = Pagina(Page, tamaño=(900, 650))
    Page.add(pagina.control)



if __name__ == "__main__":
    ft.run(main)