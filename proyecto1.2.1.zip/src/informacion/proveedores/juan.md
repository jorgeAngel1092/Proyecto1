---
nombre: juan
telefono: '67510318734'
correo: ''
productos:
- coca3
- coca
---
