---
codigo: '6761'
nombre: Pasta de trigo 500 g
caducidad: '2027-08-20'
precio: 18.5
stock: 30
stock_minimo: 0
proveedor: Alimentos del Centro
---

