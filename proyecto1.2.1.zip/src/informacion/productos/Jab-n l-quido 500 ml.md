---
codigo: '6409'
nombre: Jab?n l?quido 500 ml
caducidad: '2028-06-30'
precio: 42.0
stock: 14
stock_minimo: 0
proveedor: Higiene y Hogar
---

