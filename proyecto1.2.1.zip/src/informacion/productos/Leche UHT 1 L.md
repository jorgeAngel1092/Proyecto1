---
codigo: '8786'
nombre: Leche UHT 1 L
caducidad: '2027-03-10'
precio: 26.0
stock: 18
stock_minimo: 0
proveedor: L?cteos del Valle
---

