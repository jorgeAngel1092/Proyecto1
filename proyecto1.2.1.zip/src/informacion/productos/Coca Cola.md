---
codigo: '13245678'
nombre: Coca Cola
caducidad: '2028-12-12'
precio: 21.0
stock: 700
stock_minimo: 100
proveedor: Coca Cola
---

