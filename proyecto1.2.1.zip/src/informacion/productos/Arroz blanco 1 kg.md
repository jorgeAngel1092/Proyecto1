---
codigo: '8869'
nombre: Arroz blanco 1 kg
caducidad: '2027-10-15'
precio: 29.9
stock: 24
stock_minimo: 0
proveedor: Alimentos del Centro
---

