---
codigo: '3607'
nombre: Caf? molido 250 g
caducidad: '2027-12-01'
precio: 74.9
stock: 12
stock_minimo: 0
proveedor: Caf? de la Sierra
---

