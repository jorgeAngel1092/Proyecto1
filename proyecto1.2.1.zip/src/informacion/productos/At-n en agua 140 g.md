---
codigo: '1910'
nombre: At?n en agua 140 g
caducidad: '2028-01-05'
precio: 21.75
stock: 16
stock_minimo: 0
proveedor: Conservas del Pac?fico
---

