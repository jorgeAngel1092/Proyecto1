import math
import re
import unicodedata
from datetime import date, datetime
from io import BytesIO
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.datetime import from_excel
from openpyxl.utils.exceptions import InvalidFileException


ALIAS_CAMPOS = {
    "codigo": (
        "codigo",
        "codigoproducto",
        "codigodeproducto",
        "codigodelproducto",
        "clave",
        "claveproducto",
        "codigodebarras",
        "code",
        "productcode",
        "itemcode",
        "sku",
        "barcode",
        "ean",
    ),
    "nombre": (
        "nombre",
        "nombreproducto",
        "nombredelproducto",
        "producto",
        "descripcion",
        "name",
        "product",
        "productname",
        "item",
        "itemname",
        "description",
    ),
    "caducidad": (
        "caducidad",
        "fechacaducidad",
        "fechadecaducidad",
        "vencimiento",
        "fechavencimiento",
        "fechadevencimiento",
        "fechadeexpiracion",
        "expiration",
        "expirationdate",
        "expiry",
        "expirydate",
        "bestbefore",
    ),
    "precio": (
        "precio",
        "preciounitario",
        "precioventa",
        "preciodeventa",
        "price",
        "unitprice",
        "saleprice",
    ),
    "stock": (
        "stock",
        "existencia",
        "existencias",
        "cantidad",
        "cantidadenstock",
        "unidades",
        "stockactual",
        "inventario",
        "quantity",
        "qty",
    ),
    "stock_minimo": (
        "stockminimo",
        "minimostock",
        "stockmin",
        "minstock",
        "minimumstock",
        "reorderlevel",
        "minimum",
        "minimo",
    ),
    "proveedor": (
        "proveedor",
        "nombreproveedor",
        "supplier",
        "vendor",
    ),
}


class ArchivoExcelError(ValueError):
    """Error legible al leer o convertir una hoja de cálculo."""


def _normalizar_encabezado(valor):
    texto = unicodedata.normalize("NFKD", str(valor or "").casefold())
    return "".join(
        caracter
        for caracter in texto
        if not unicodedata.combining(caracter) and caracter.isalnum()
    )


ALIAS_NORMALIZADOS = {
    campo: {_normalizar_encabezado(alias) for alias in aliases}
    for campo, aliases in ALIAS_CAMPOS.items()
}


def _abrir_libro(origen):
    if isinstance(origen, bytes):
        origen = BytesIO(origen)
    try:
        return load_workbook(origen, read_only=True, data_only=True)
    except (BadZipFile, InvalidFileException, OSError, ValueError) as error:
        raise ArchivoExcelError(
            "No se pudo leer el archivo. Selecciona un libro .xlsx o .xlsm válido."
        ) from error


def listar_hojas_excel(origen):
    """Devuelve los nombres de las hojas del libro Excel."""
    libro = _abrir_libro(origen)
    try:
        return list(libro.sheetnames)
    finally:
        libro.close()


def _mapear_encabezados(celdas):
    columnas = {}
    for indice, celda in enumerate(celdas):
        encabezado = _normalizar_encabezado(celda.value)
        if not encabezado:
            continue
        for campo, alias in ALIAS_NORMALIZADOS.items():
            if campo not in columnas and encabezado in alias:
                columnas[campo] = (indice, str(celda.value).strip())
    return columnas


def _detectar_encabezados(hoja):
    limite = min(max(hoja.max_row or 1, 1), 10)
    mejor = None
    for fila, celdas in enumerate(
        hoja.iter_rows(min_row=1, max_row=limite),
        start=1,
    ):
        columnas = _mapear_encabezados(celdas)
        if "nombre" in columnas and (
            mejor is None or len(columnas) > len(mejor[1])
        ):
            mejor = (fila, columnas)

    if mejor is None:
        raise ArchivoExcelError(
            "No se encontró una columna de nombre, producto o descripción "
            "en las primeras 10 filas."
        )
    return mejor


def _texto_celda(celda, conservar_ceros=False):
    valor = celda.value
    if valor is None:
        return ""
    if isinstance(valor, datetime):
        return valor.strftime("%Y-%m-%d")
    if isinstance(valor, date):
        return valor.isoformat()
    if isinstance(valor, bool):
        return str(valor)
    if isinstance(valor, (int, float)):
        formato = str(celda.number_format or "")
        if (
            conservar_ceros
            and isinstance(valor, (int, float))
            and float(valor).is_integer()
            and formato
            and set(formato) == {"0"}
        ):
            return f"{int(valor):0{len(formato)}d}"
        if float(valor).is_integer():
            return str(int(valor))
    return str(valor).strip()


def _numero(valor, campo, predeterminado):
    if valor is None or (isinstance(valor, str) and not valor.strip()):
        return float(predeterminado)
    if isinstance(valor, bool):
        raise ValueError(f"{campo} debe ser numérico.")

    if isinstance(valor, (int, float)):
        resultado = float(valor)
    else:
        texto = re.sub(r"[\s$€£¥₱]", "", str(valor).strip())
        if not re.fullmatch(r"[+-]?\d[\d.,]*", texto):
            raise ValueError(f"{campo} debe ser numérico.")
        if "," in texto and "." in texto:
            if texto.rfind(",") > texto.rfind("."):
                texto = texto.replace(".", "").replace(",", ".")
            else:
                texto = texto.replace(",", "")
        elif "," in texto:
            if re.fullmatch(r"[+-]?\d{1,3}(,\d{3})+", texto):
                texto = texto.replace(",", "")
            else:
                texto = texto.replace(",", ".")
        try:
            resultado = float(texto)
        except ValueError as error:
            raise ValueError(f"{campo} debe ser numérico.") from error

    if not math.isfinite(resultado) or resultado < 0:
        raise ValueError(f"{campo} no puede ser negativo ni inválido.")
    return resultado


def _entero(valor, campo):
    resultado = _numero(valor, campo, 0)
    if not resultado.is_integer():
        raise ValueError(f"{campo} debe ser un número entero.")
    return int(resultado)


def _fecha(valor, epoca):
    if valor is None or (isinstance(valor, str) and not valor.strip()):
        return ""
    if isinstance(valor, datetime):
        return valor.strftime("%Y-%m-%d")
    if isinstance(valor, date):
        return valor.isoformat()
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        try:
            convertido = from_excel(valor, epoca)
        except (TypeError, ValueError) as error:
            raise ValueError("La fecha de caducidad no es válida.") from error
        if isinstance(convertido, (datetime, date)):
            if isinstance(convertido, datetime):
                return convertido.strftime("%Y-%m-%d")
            return convertido.isoformat()

    texto = str(valor).strip()
    try:
        return datetime.fromisoformat(texto).strftime("%Y-%m-%d")
    except ValueError:
        pass
    for formato in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(texto, formato).strftime("%Y-%m-%d")
        except ValueError:
            continue
    raise ValueError("La fecha debe usar AAAA-MM-DD o DD/MM/AAAA.")


def leer_productos_excel(origen, nombre_hoja):
    """Convierte una hoja Excel en productos y errores identificados por fila."""
    libro = _abrir_libro(origen)
    try:
        if nombre_hoja not in libro.sheetnames:
            raise ArchivoExcelError("La hoja seleccionada no existe en el libro.")
        hoja = libro[nombre_hoja]
        fila_encabezados, columnas = _detectar_encabezados(hoja)
        etiquetas = {
            campo: etiqueta
            for campo, (_, etiqueta) in columnas.items()
        }
        productos = []
        errores = []

        for numero_fila, celdas in enumerate(
            hoja.iter_rows(min_row=fila_encabezados + 1),
            start=fila_encabezados + 1,
        ):
            if not any(celda.value is not None for celda in celdas):
                continue

            def valor_celda(campo):
                columna = columnas.get(campo)
                if columna is None or columna[0] >= len(celdas):
                    return None
                return celdas[columna[0]]

            try:
                celda_nombre = valor_celda("nombre")
                nombre = _texto_celda(celda_nombre) if celda_nombre else ""
                if not nombre:
                    raise ValueError("El nombre del producto es obligatorio.")

                celda_codigo = valor_celda("codigo")
                celda_fecha = valor_celda("caducidad")
                celda_precio = valor_celda("precio")
                celda_stock = valor_celda("stock")
                celda_minimo = valor_celda("stock_minimo")
                celda_proveedor = valor_celda("proveedor")

                datos = {
                    "codigo": (
                        _texto_celda(celda_codigo, conservar_ceros=True)
                        if celda_codigo
                        else ""
                    ),
                    "nombre": nombre,
                    "caducidad": (
                        _fecha(celda_fecha.value, libro.epoch)
                        if celda_fecha
                        else ""
                    ),
                    "precio": _numero(
                        celda_precio.value if celda_precio else None,
                        "Precio",
                        0,
                    ),
                    "stock": _entero(
                        celda_stock.value if celda_stock else None,
                        "Stock",
                    ),
                    "stock_minimo": _entero(
                        celda_minimo.value if celda_minimo else None,
                        "Stock mínimo",
                    ),
                    "proveedor": (
                        _texto_celda(celda_proveedor)
                        if celda_proveedor
                        else ""
                    ),
                }
            except ValueError as error:
                errores.append({"fila": numero_fila, "mensaje": str(error)})
                continue

            productos.append({"fila": numero_fila, "datos": datos})

        return {
            "hoja": nombre_hoja,
            "fila_encabezados": fila_encabezados,
            "columnas": etiquetas,
            "productos": productos,
            "errores": errores,
        }
    finally:
        libro.close()
