import flet as ft
from src.clase.funciones_obsidian import (
    apartar_producto,
    eliminar_apartado,
    buscar_productos as buscar_productos_storage,
    leer_apartados,
)


class Ventana4:
    def __init__(self, page: ft.Page, tamaño):
        self.page = page
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.on_movimiento = None
        self.on_inventario_cambiado = None
        self.producto_seleccionado = None

        self.campo_producto = ft.TextField(
            label="Buscar por nombre o código",
            bgcolor="#FFFFFF",
            filled=True,
            expand=True,
        )
        self.campo_producto.on_change = self.buscar_productos
        self.campo_codigo = ft.TextField(
            label="Código",
            bgcolor="#FFFFFF",
            filled=True,
            expand=True,
            read_only=True,
        )
        self.texto_stock_disponible = ft.Text(
            value="Selecciona un producto para ver su stock.",
            color="#CBD5E1",
        )
        self.lista_sugerencias = ft.Column(
            controls=[],
            spacing=4,
            visible=False,
        )
        self.campo_cantidad = ft.TextField(
            label="Cantidad",
            keyboard_type=ft.KeyboardType.NUMBER,
            bgcolor="#FFFFFF",
            filled=True,
            expand=True,
        )
        self.campo_cliente = ft.TextField(
            label="Nombre del cliente",
            bgcolor="#FFFFFF",
            filled=True,
            expand=True,
        )
        self.campo_telefono = ft.TextField(
            label="Teléfono de contacto",
            bgcolor="#FFFFFF",
            filled=True,
            expand=True,
        )
        self.texto_estado = ft.Text(value="", color="#F8FAFC")
        self.tabla_apartados = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Producto", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Código", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Cantidad", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Cliente", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Teléfono", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Fecha", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Acción", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
            ],
            rows=[],
            column_spacing=16,
        )

        self.ventana_4 = ft.Container(
            content=ft.Column(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Productos apartados",
                                size=26,
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Registra apartados y consulta los que siguen pendientes.",
                                color="#CBD5E1",
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=4,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [
                                        self.campo_producto,
                                        self.campo_codigo,
                                    ],
                                    spacing=12,
                                ),
                                self.lista_sugerencias,
                                self.texto_stock_disponible,
                                ft.Row(
                                    [
                                        self.campo_cantidad,
                                        self.campo_cliente,
                                    ],
                                    spacing=12,
                                ),
                                ft.Row(
                                    [
                                        self.campo_telefono,
                                        ft.Button(
                                            content="Registrar apartado",
                                            on_click=self.registrar,
                                            bgcolor="#2563EB",
                                            color="#FFFFFF",
                                            height=44,
                                        ),
                                    ],
                                    spacing=12,
                                ),
                                self.texto_estado,
                            ],
                            spacing=12,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        padding=18,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [self.tabla_apartados],
                                    scroll=ft.ScrollMode.AUTO,
                                )
                            ],
                            scroll=ft.ScrollMode.AUTO,
                            expand=True,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        padding=10,
                        expand=True,
                    ),
                ],
                spacing=14,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )
        self.actualizar_lista()

    def registrar(self, evento=None):
        producto = self.producto_seleccionado
        cliente = self.campo_cliente.value.strip()
        try:
            cantidad = int(self.campo_cantidad.value or 0)
        except ValueError:
            cantidad = 0

        if not producto or not cliente or cantidad <= 0:
            self.texto_estado.value = (
                "Selecciona un producto, indica el cliente y una cantidad mayor que cero."
            )
            self.texto_estado.color = "#FCA5A5"
            self.page.update()
            return

        try:
            _, producto_guardado = apartar_producto(
                producto.get("codigo") or producto.get("nombre"),
                cantidad,
                cliente,
                self.campo_telefono.value.strip(),
            )
        except ValueError as error:
            self.texto_estado.value = str(error)
            self.texto_estado.color = "#FCA5A5"
            self.page.update()
            return

        if self.on_movimiento:
            self.on_movimiento(
                "Producto apartado",
                f"{producto_guardado['nombre']} x{cantidad} para {cliente}",
            )
        if self.on_inventario_cambiado:
            self.on_inventario_cambiado()
        self.producto_seleccionado = None
        self.campo_producto.value = ""
        self.campo_codigo.value = ""
        self.campo_cantidad.value = ""
        self.campo_cliente.value = ""
        self.campo_telefono.value = ""
        self.texto_stock_disponible.value = "Selecciona un producto para ver su stock."
        self.texto_estado.value = "Apartado registrado."
        self.texto_estado.color = "#86EFAC"
        self.actualizar_lista()
        self.page.update()

    def buscar_productos(self, evento=None):
        consulta = self.campo_producto.value.strip()
        self.producto_seleccionado = None
        self.campo_codigo.value = ""
        if len(consulta) < 1:
            self.lista_sugerencias.controls.clear()
            self.lista_sugerencias.visible = False
            self.texto_stock_disponible.value = (
                "Selecciona un producto para ver su stock."
            )
            self.page.update()
            return

        resultados = buscar_productos_storage(consulta)
        self.lista_sugerencias.controls.clear()
        for producto in resultados[:8]:
            self.lista_sugerencias.controls.append(
                ft.Button(
                    content=(
                        f"{producto.get('nombre', '')} "
                        f"· Código: {producto.get('codigo', '—')} "
                        f"· Stock: {producto.get('stock', 0)}"
                    ),
                    on_click=self.crear_evento_seleccionar(producto),
                    bgcolor="#334155",
                    color="#F8FAFC",
                )
            )
        self.lista_sugerencias.visible = bool(self.lista_sugerencias.controls)
        if not self.lista_sugerencias.controls:
            self.lista_sugerencias.controls.append(
                ft.Text("No se encontraron productos.", color="#FCA5A5")
            )
            self.lista_sugerencias.visible = True
        self.page.update()

    def crear_evento_seleccionar(self, producto):
        def seleccionar(evento):
            self.producto_seleccionado = producto
            self.campo_producto.value = str(producto.get("nombre", ""))
            self.campo_codigo.value = str(producto.get("codigo", ""))
            self.texto_stock_disponible.value = (
                f"Stock disponible: {producto.get('stock', 0)}"
            )
            self.lista_sugerencias.controls.clear()
            self.lista_sugerencias.visible = False
            self.page.update()

        return seleccionar

    def actualizar_lista(self):
        self.tabla_apartados.rows.clear()
        for apartado in leer_apartados():
            archivo = apartado.get("_archivo", "")
            self.tabla_apartados.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(str(apartado.get("producto", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(apartado.get("codigo", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(apartado.get("cantidad", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(apartado.get("cliente", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(apartado.get("telefono", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(apartado.get("fecha", "")), color="#F1F5F9")),
                        ft.DataCell(
                            ft.Button(
                                content="Completar",
                                on_click=self.crear_evento_completar(archivo, apartado),
                                bgcolor="#166534",
                                color="#FFFFFF",
                            )
                        ),
                    ]
                )
            )
        self.page.update()

    def crear_evento_completar(self, archivo, apartado):
        def completar(evento):
            eliminar_apartado(archivo)
            if self.on_movimiento:
                self.on_movimiento(
                    "Apartado completado",
                    f"{apartado.get('producto', '')} para {apartado.get('cliente', '')}",
                )
            self.texto_estado.value = "Apartado completado y retirado de la lista."
            self.texto_estado.color = "#86EFAC"
            self.actualizar_lista()

        return completar
