import ipaddress
import json
import ssl
from pathlib import Path
from urllib.parse import quote

import httpx


ROOT_DIR = Path(__file__).resolve().parents[2]
VAULT_DIR = ROOT_DIR / "src" / "informacion" / "productos"
CONFIG_FILE = ROOT_DIR / "variables.json"
PLUGIN_CONFIG_FILE = (
    VAULT_DIR
    / ".obsidian"
    / "plugins"
    / "obsidian-local-rest-api"
    / "data.json"
)


class ObsidianAPIError(RuntimeError):
    """Error de configuración o comunicación con la API local de Obsidian."""


class ObsidianLocalAPI:
    def __init__(self):
        config = self._read_json(CONFIG_FILE, "No se pudo leer variables.json.")
        if not isinstance(config, dict):
            raise ObsidianAPIError("variables.json debe contener un objeto JSON.")
        host_value = config.get("host")
        key_value = config.get("key")
        host = host_value.strip() if isinstance(host_value, str) else ""
        key = key_value.strip() if isinstance(key_value, str) else ""

        try:
            port = int(config.get("puerto"))
        except (TypeError, ValueError) as error:
            raise ObsidianAPIError(
                "El puerto de Obsidian en variables.json no es válido."
            ) from error

        if not host or not key or not 1 <= port <= 65535:
            raise ObsidianAPIError(
                "variables.json debe incluir host, puerto y key válidos."
            )
        self._validate_local_host(host)
        url_host = f"[{host}]" if ":" in host else host
        self._base_url = f"https://{url_host}:{port}"
        self._headers = {"Authorization": f"Bearer {key}"}
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=self._headers,
            verify=self._ssl_context(),
            timeout=10,
            trust_env=False,
            follow_redirects=False,
        )

    @staticmethod
    def _read_json(path, error_message):
        try:
            with path.open("r", encoding="utf-8") as file:
                return json.load(file)
        except (OSError, json.JSONDecodeError) as error:
            raise ObsidianAPIError(error_message) from error

    @staticmethod
    def _validate_local_host(host):
        if host.lower() == "localhost":
            return
        try:
            address = ipaddress.ip_address(host)
        except ValueError as error:
            raise ObsidianAPIError(
                "Por seguridad, la API solo puede usar un host local "
                "(localhost o una dirección loopback)."
            ) from error
        if not address.is_loopback:
            raise ObsidianAPIError(
                "Por seguridad, la API solo puede usar un host local "
                "(localhost o una dirección loopback)."
            )

    @classmethod
    def _ssl_context(cls):
        if not PLUGIN_CONFIG_FILE.is_file():
            raise ObsidianAPIError(
                "No se encontró el certificado TLS de Local REST API "
                "en la configuración local de Obsidian."
            )
        settings = cls._read_json(
            PLUGIN_CONFIG_FILE,
            "No se pudo leer la configuración TLS local de Obsidian.",
        )
        crypto = settings.get("crypto") if isinstance(settings, dict) else None
        ca_certificate = crypto.get("caCert") if isinstance(crypto, dict) else None
        if not isinstance(ca_certificate, str) or not ca_certificate.strip():
            raise ObsidianAPIError(
                "No se encontró la autoridad certificadora TLS de Obsidian."
            )
        try:
            return ssl.create_default_context(cadata=ca_certificate)
        except (ssl.SSLError, ValueError) as error:
            raise ObsidianAPIError(
                "El certificado TLS local de Obsidian no es válido."
            ) from error

    @staticmethod
    def _vault_url(path, directory=False):
        normalized = str(path or "").replace("\\", "/").strip("/")
        parts = normalized.split("/") if normalized else []
        if any(part in ("", ".", "..") for part in parts):
            raise ValueError("La ruta de Obsidian no es válida.")
        if any(part.lower() == ".obsidian" for part in parts):
            raise ValueError("No se permite acceder a la configuración de Obsidian.")
        encoded = "/".join(quote(part, safe="") for part in parts)
        suffix = f"{encoded}/" if directory and encoded else encoded
        return f"/vault/{suffix}"

    def _request(self, method, path, *, directory=False, content=None):
        url = self._vault_url(path, directory=directory)
        try:
            response = self._client.request(
                method,
                url,
                content=content,
                headers={"Content-Type": "text/markdown"} if content is not None else None,
            )
        except httpx.TimeoutException as error:
            raise ObsidianAPIError(
                "Obsidian no respondió a tiempo. Comprueba que esté abierto."
            ) from error
        except httpx.RequestError as error:
            raise ObsidianAPIError(
                "No se pudo establecer una conexión TLS segura con Obsidian. "
                "Comprueba el plugin Local REST API, su certificado y la configuración."
            ) from error

        if response.status_code == 401:
            raise ObsidianAPIError(
                "Obsidian rechazó la API key. Comprueba variables.json."
            )
        if response.status_code == 403:
            raise ObsidianAPIError(
                "Obsidian denegó el acceso a la ruta solicitada."
            )
        if response.status_code == 429:
            raise ObsidianAPIError(
                "Obsidian limitó temporalmente las solicitudes. Inténtalo más tarde."
            )
        return response

    def verify_connection(self):
        try:
            response = self._client.get("/")
        except httpx.TimeoutException as error:
            raise ObsidianAPIError(
                "Obsidian no respondió a tiempo. Comprueba que esté abierto."
            ) from error
        except httpx.RequestError as error:
            raise ObsidianAPIError(
                "No se pudo establecer una conexión TLS segura con Obsidian. "
                "Comprueba el plugin Local REST API, su certificado y la configuración."
            ) from error

        if response.status_code == 401:
            raise ObsidianAPIError(
                "Obsidian rechazó la API key. Comprueba variables.json."
            )
        if not response.is_success:
            raise ObsidianAPIError(
                f"Obsidian respondió con el estado HTTP {response.status_code}."
            )
        try:
            authenticated = response.json().get("authenticated")
        except (ValueError, AttributeError) as error:
            raise ObsidianAPIError(
                "Obsidian respondió en un formato inesperado."
            ) from error
        if authenticated is not True:
            raise ObsidianAPIError(
                "Obsidian no confirmó la autenticación de la API key."
            )

    def read_note(self, path):
        response = self._request("GET", path)
        if response.status_code == 404:
            return None
        if not response.is_success:
            raise ObsidianAPIError(
                f"Obsidian no pudo leer la nota (HTTP {response.status_code})."
            )
        return response.text

    def list_files(self, folder=""):
        response = self._request("GET", folder, directory=True)
        if response.status_code == 404:
            return []
        if not response.is_success:
            raise ObsidianAPIError(
                f"Obsidian no pudo listar la carpeta (HTTP {response.status_code})."
            )
        try:
            files = response.json().get("files")
        except (ValueError, AttributeError) as error:
            raise ObsidianAPIError(
                "Obsidian devolvió un listado de archivos no válido."
            ) from error
        if not isinstance(files, list) or any(not isinstance(item, str) for item in files):
            raise ObsidianAPIError(
                "Obsidian devolvió un listado de archivos no válido."
            )
        return files

    def write_note(self, path, content):
        response = self._request("PUT", path, content=content.encode("utf-8"))
        if not response.is_success:
            raise ObsidianAPIError(
                f"Obsidian no pudo guardar la nota (HTTP {response.status_code})."
            )

    def delete_note(self, path):
        response = self._request("DELETE", path)
        if response.status_code == 404:
            return
        if not response.is_success:
            raise ObsidianAPIError(
                f"Obsidian no pudo eliminar la nota (HTTP {response.status_code})."
            )


_api = None


def get_obsidian_api():
    global _api
    if _api is None:
        _api = ObsidianLocalAPI()
    return _api
