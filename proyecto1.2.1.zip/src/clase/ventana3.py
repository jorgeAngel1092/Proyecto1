import os

import flet as ft
from src.clase.funciones_obsidian import (
    guardar_corte_turno,
    leer_cortes,
    leer_turno,
    registrar_movimiento_turno,
)


class Ventana3:
    def __init__(self, page: ft.Page, tamaño):
        self.page = page
        self.page.title = "Gestión de Turnos"
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.turno_anterior = "Matutino"

        self.selector_turno = ft.Dropdown(
            label="Turno",
            value="Matutino",
            options=[
                ft.dropdown.Option("Matutino"),
                ft.dropdown.Option("Vespertino"),
                ft.dropdown.Option("Nocturno"),
            ],
            border_radius=4,
            filled=True,
            bgcolor="#312E81",
            color="#FFFFFF",
            expand=True,
        )
        self.texto_estado = ft.Text(
            value="",
            color="#E2E8F0",
            weight=ft.FontWeight.W_500,
            text_align=ft.TextAlign.CENTER,
        )
        self.tabla_movimientos = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Hora", color="#FFFFFF", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Movimiento", color="#FFFFFF", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Detalle", color="#FFFFFF", weight=ft.FontWeight.BOLD)),
            ],
            rows=[],
            column_spacing=20,
            horizontal_margin=12,
        )
        self.lista_cortes = ft.Column(
            controls=[],
            spacing=8,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
        )

        self.ventana_3 = ft.Container(
            content=ft.Column(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Cortes por turno",
                                size=26,
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Consulta los movimientos automáticos y cambia al siguiente turno.",
                                color="#CBD5E1",
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [
                                        ft.Container(
                                            content=self.selector_turno,
                                            expand=True,
                                        ),
                                        ft.Button(
                                            content="Cambiar al siguiente turno",
                                            on_click=self.cambiar_siguiente_turno,
                                            bgcolor="#166534",
                                            color="#FFFFFF",
                                            height=44,
                                        ),
                                    ],
                                    spacing=12,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                ),
                                self.texto_estado,
                            ],
                            spacing=12,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        padding=20,
                    ),
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            "Movimientos del turno",
                                            weight=ft.FontWeight.BOLD,
                                            color="#F8FAFC",
                                        ),
                                        ft.Column(
                                            [ft.Row([self.tabla_movimientos])],
                                            scroll=ft.ScrollMode.AUTO,
                                            expand=True,
                                        ),
                                    ],
                                    spacing=8,
                                ),
                                bgcolor="#1E293B",
                                border=ft.Border.all(1, "#475569"),
                                border_radius=6,
                                padding=14,
                                expand=True,
                            ),
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            "Cortes guardados",
                                            weight=ft.FontWeight.BOLD,
                                            color="#F8FAFC",
                                        ),
                                        self.lista_cortes,
                                    ],
                                    spacing=8,
                                    expand=True,
                                ),
                                bgcolor="#1E293B",
                                border=ft.Border.all(1, "#475569"),
                                border_radius=6,
                                padding=14,
                                expand=True,
                                height=280,
                            ),
                        ],
                        spacing=12,
                        expand=True,
                    ),
                ],
                spacing=14,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )

        self.actualizar_turno()
        self.actualizar_cortes()

    def cambiar_siguiente_turno(self, evento=None):
        turnos = ["Matutino", "Vespertino", "Nocturno"]
        turno_actual = self.selector_turno.value
        indice = turnos.index(turno_actual) if turno_actual in turnos else 0
        siguiente = turnos[(indice + 1) % len(turnos)]

        datos_turno = leer_turno(turno_actual)
        movimientos = datos_turno.get("movimientos", [])
        if movimientos:
            corte = guardar_corte_turno(turno_actual)
            cantidad = len(corte.get("movimientos", []))
            self.texto_estado.value = (
                f"Corte automático: {cantidad} movimientos guardados "
                f"del turno {turno_actual}. Ahora continúa {siguiente}."
            )
            self.texto_estado.color = "#86EFAC"
        else:
            self.texto_estado.value = (
                f"Sin movimientos en {turno_actual}. Se cambió a {siguiente}."
            )
            self.texto_estado.color = "#93C5FD"

        self.turno_anterior = siguiente
        self.selector_turno.value = siguiente
        self.actualizar_turno()
        self.actualizar_cortes()
        self.page.update()

    def registrar_movimiento(self, tipo, detalle):
        registrar_movimiento_turno(
            self.selector_turno.value,
            {
                "tipo": tipo,
                "concepto": detalle,
            },
        )
        self.actualizar_turno()
        self.page.update()

    def actualizar_turno(self):
        datos = leer_turno(self.selector_turno.value)
        movimientos = datos.get("movimientos", [])
        self.tabla_movimientos.rows.clear()

        for movimiento in movimientos:
            fecha = str(movimiento.get("fecha", ""))
            hora = fecha.split(" ")[-1] if " " in fecha else fecha
            self.tabla_movimientos.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(hora, color="#F8FAFC")),
                        ft.DataCell(ft.Text(str(movimiento.get("tipo", "")), color="#F8FAFC")),
                        ft.DataCell(ft.Text(str(movimiento.get("concepto", "")), color="#F8FAFC")),
                    ]
                )
            )

    def actualizar_cortes(self):
        self.lista_cortes.controls.clear()
        for corte in leer_cortes():
            movimientos = corte.get("movimientos", [])
            total_movimientos = len(movimientos)
            self.lista_cortes.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                f'{corte.get("turno", "Turno")} - {corte.get("fecha", "")}',
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                            ),
                            ft.Text(
                                f"Movimientos: {total_movimientos}",
                                size=12,
                                color="#CBD5E1",
                            ),
                            ft.Text(
                                f'Reporte guardado: {os.path.basename(corte.get("reporte", ""))}',
                                size=11,
                                color="#BFDBFE",
                                selectable=True,
                            ),
                        ],
                        spacing=2,
                    ),
                    bgcolor="#334155",
                    border=ft.Border.all(1, "#475569"),
                    border_radius=4,
                    padding=10,
                )
            )

        if not self.lista_cortes.controls:
            self.lista_cortes.controls.append(
                ft.Text(
                    "Todavía no hay cortes guardados.",
                    color="#94A3B8",
                )
            )
