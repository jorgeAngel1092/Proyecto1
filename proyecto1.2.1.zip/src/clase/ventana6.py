import os
import secrets

import flet as ft
from src.clase.funciones_obsidian import (
    guardar_producto,
    leer_todos,
    nombre_archivo_seguro,
)
from src.clase.importador_excel import (
    ArchivoExcelError,
    leer_productos_excel,
    listar_hojas_excel,
)
from src.clase.obsidian_api import ObsidianAPIError


class Ventana6:
    def __init__(self, page: ft.Page, tamaño):
        self.page = page
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.on_producto_cambiado = None
        self.on_movimiento = None
        self.archivo_path = None
        self.archivo_nombre = ""
        self.resultado_excel = None
        self.errores_importacion = []

        self.selector_archivo = ft.FilePicker(on_result=self.archivo_seleccionado)
        self.page.services.append(self.selector_archivo)

        self.texto_archivo = ft.Text(
            "Ningún archivo seleccionado.",
            color="#CBD5E1",
            selectable=True,
        )
        self.selector_hoja = ft.Dropdown(
            label="Hoja de cálculo",
            options=[],
            visible=False,
            bgcolor="#FFFFFF",
            expand=True,
            on_select=self.cargar_hoja,
        )
        self.texto_mapeo = ft.Text(value="", color="#BFDBFE", size=12)
        self.texto_resumen = ft.Text(
            "Selecciona un archivo .xlsx o .xlsm para previsualizar sus productos.",
            color="#CBD5E1",
        )
        self.texto_estado = ft.Text(value="", color="#F8FAFC")
        self.lista_errores = ft.Column(
            controls=[],
            spacing=4,
            scroll=ft.ScrollMode.AUTO,
        )
        self.tabla_productos = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Fila", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Código", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Nombre", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Caducidad", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Precio", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Stock", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Mínimo", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Proveedor", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
            ],
            rows=[],
            column_spacing=14,
            horizontal_margin=12,
        )
        self.boton_importar = ft.Button(
            content="Importar productos válidos",
            on_click=self.importar,
            disabled=True,
            bgcolor="#166534",
            color="#FFFFFF",
            height=44,
        )

        self.ventana_6 = ft.Container(
            content=ft.Column(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Importar productos desde Excel",
                                size=26,
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Admite .xlsx/.xlsm; detecta nombre, código, caducidad, precio, stock y proveedor; omite duplicados.",
                                color="#CBD5E1",
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=4,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [
                                        ft.Button(
                                            content="Seleccionar archivo Excel",
                                            action=ft.PickFiles(
                                                self.selector_archivo,
                                                file_type=ft.FilePickerFileType.CUSTOM,
                                                allowed_extensions=["xlsx", "xlsm"],
                                                allow_multiple=False,
                                            ),
                                            bgcolor="#2563EB",
                                            color="#FFFFFF",
                                            height=44,
                                        ),
                                        self.texto_archivo,
                                    ],
                                    spacing=12,
                                    wrap=True,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                ),
                                self.selector_hoja,
                                self.texto_mapeo,
                                self.texto_resumen,
                                self.lista_errores,
                                ft.Row(
                                    [self.boton_importar, self.texto_estado],
                                    spacing=12,
                                    wrap=True,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                ),
                            ],
                            spacing=10,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        padding=18,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    "Vista previa",
                                    weight=ft.FontWeight.BOLD,
                                    color="#F8FAFC",
                                ),
                                ft.Row(
                                    [self.tabla_productos],
                                    scroll=ft.ScrollMode.AUTO,
                                ),
                            ],
                            spacing=8,
                            scroll=ft.ScrollMode.AUTO,
                            expand=True,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        padding=10,
                        expand=True,
                    ),
                ],
                spacing=14,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )

    def archivo_seleccionado(self, evento: ft.FilePickerResultEvent):
        archivos = evento.files or []
        if not archivos:
            return

        self.archivo_path = None
        self.resultado_excel = None
        self.errores_importacion = []
        self.boton_importar.disabled = True
        self.tabla_productos.rows.clear()
        self.lista_errores.controls.clear()
        self.selector_hoja.options = []
        self.selector_hoja.value = None
        self.selector_hoja.visible = False
        self.texto_mapeo.value = ""
        self.texto_resumen.value = (
            "Selecciona un archivo .xlsx o .xlsm para previsualizar sus productos."
        )
        archivo = archivos[0]
        self.archivo_nombre = archivo.name
        self.texto_archivo.value = archivo.name
        extension = os.path.splitext(archivo.name)[1].lower()
        if extension not in (".xlsx", ".xlsm"):
            self._mostrar_error("Selecciona un archivo .xlsx o .xlsm.")
            return
        if not archivo.path:
            self._mostrar_error(
                "No se pudo acceder a la ruta del archivo seleccionado."
            )
            return

        self.archivo_path = archivo.path

        try:
            hojas = listar_hojas_excel(self.archivo_path)
        except ArchivoExcelError as error:
            self._mostrar_error(str(error))
            return

        if not hojas:
            self._mostrar_error("El archivo no contiene hojas de cálculo.")
            return
        self.selector_hoja.options = [
            ft.dropdown.Option(nombre) for nombre in hojas
        ]
        self.selector_hoja.value = hojas[0]
        self.selector_hoja.visible = True
        self.cargar_hoja()

    def cargar_hoja(self, evento=None):
        if not self.archivo_path or not self.selector_hoja.value:
            return
        self.resultado_excel = None
        self.tabla_productos.rows.clear()
        self.lista_errores.controls.clear()
        self.boton_importar.disabled = True
        try:
            resultado = leer_productos_excel(
                self.archivo_path,
                self.selector_hoja.value,
            )
        except ArchivoExcelError as error:
            self.resultado_excel = None
            self.tabla_productos.rows.clear()
            self.boton_importar.disabled = True
            self._mostrar_error(str(error))
            return

        self.resultado_excel = resultado
        self.texto_estado.value = ""
        self.texto_mapeo.value = "Columnas detectadas: " + ", ".join(
            f"{campo.replace('_', ' ')} ← {etiqueta}"
            for campo, etiqueta in resultado["columnas"].items()
        )
        productos = resultado["productos"]
        errores = resultado["errores"]
        self.texto_resumen.value = (
            f"{len(productos)} filas válidas · {len(errores)} filas con errores. "
            "Se muestran hasta 100 productos."
        )
        self.tabla_productos.rows.clear()
        for fila in productos[:100]:
            datos = fila["datos"]
            self.tabla_productos.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(str(fila["fila"]), color="#CBD5E1")),
                        ft.DataCell(ft.Text(datos["codigo"], color="#F1F5F9")),
                        ft.DataCell(ft.Text(datos["nombre"], color="#F1F5F9")),
                        ft.DataCell(ft.Text(datos["caducidad"], color="#F1F5F9")),
                        ft.DataCell(ft.Text(f'{datos["precio"]:g}', color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(datos["stock"]), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(datos["stock_minimo"]), color="#F1F5F9")),
                        ft.DataCell(ft.Text(datos["proveedor"], color="#F1F5F9")),
                    ]
                )
            )

        self.errores_importacion = list(errores)
        self._actualizar_errores()
        self.boton_importar.disabled = not productos
        self.page.update()

    def importar(self, evento=None):
        if not self.resultado_excel:
            return

        try:
            existentes = leer_todos()
        except ObsidianAPIError as error:
            self._mostrar_error(str(error))
            return

        nombres = {
            str(producto.get("nombre", "")).strip().casefold()
            for producto in existentes
            if producto
        }
        nombres_archivo = {
            nombre_archivo_seguro(producto.get("nombre", "")).casefold()
            for producto in existentes
            if producto
        }
        codigos = {
            str(producto.get("codigo", "")).strip().casefold()
            for producto in existentes
            if producto and producto.get("codigo")
        }
        codigos_reservados = set(codigos)
        codigos_reservados.update(
            fila["datos"]["codigo"].strip().casefold()
            for fila in self.resultado_excel["productos"]
            if fila["datos"]["codigo"].strip()
        )
        guardados = 0
        omitidos = 0
        codigos_generados = 0
        error_api = None

        for indice, fila in enumerate(self.resultado_excel["productos"]):
            datos = fila["datos"]
            nombre = datos["nombre"].strip().casefold()
            nombre_archivo = nombre_archivo_seguro(datos["nombre"]).casefold()
            codigo = datos["codigo"].strip().casefold()
            if (
                nombre in nombres
                or nombre_archivo in nombres_archivo
                or (codigo and codigo in codigos)
            ):
                omitidos += 1
                self.errores_importacion.append({
                    "fila": fila["fila"],
                    "mensaje": "El nombre o código ya existe; se omitió para no sobrescribirlo.",
                })
                continue

            codigo_generado = False
            if not codigo:
                try:
                    codigo = self._generar_codigo(codigos_reservados)
                except ValueError as error:
                    self.texto_estado.value = str(error)
                    self.texto_estado.color = "#FCA5A5"
                    self.page.update()
                    return
                datos["codigo"] = codigo
                codigos_reservados.add(codigo)
                codigo_generado = True
                if indice < len(self.tabla_productos.rows):
                    self.tabla_productos.rows[indice].cells[1].content.value = codigo

            try:
                guardar_producto(datos)
            except ValueError as error:
                omitidos += 1
                self.errores_importacion.append({
                    "fila": fila["fila"],
                    "mensaje": str(error),
                })
                continue
            except ObsidianAPIError as error:
                error_api = error
                break

            nombres.add(nombre)
            nombres_archivo.add(nombre_archivo)
            if codigo:
                codigos.add(codigo)
            guardados += 1
            if codigo_generado:
                codigos_generados += 1

        errores_sistema = []
        if guardados:
            if self.on_movimiento:
                try:
                    self.on_movimiento(
                        "Importación desde Excel",
                        f"{self.archivo_nombre}: {guardados} productos",
                    )
                except ObsidianAPIError as error:
                    errores_sistema.append(
                        f"No se pudo registrar el movimiento: {error}"
                    )
            if self.on_producto_cambiado:
                try:
                    self.on_producto_cambiado()
                except ObsidianAPIError as error:
                    errores_sistema.append(
                        f"No se pudo actualizar el inventario visible: {error}"
                    )

        if error_api:
            self.texto_estado.value = (
                f"Se importaron {guardados} productos y se asignaron "
                f"{codigos_generados} códigos antes del error: {error_api}"
            )
        else:
            self.texto_estado.value = (
                f"Importados: {guardados} · códigos asignados: {codigos_generados} "
                f"· omitidos: {omitidos}."
            )
        if errores_sistema:
            self.texto_estado.value += " " + " ".join(errores_sistema)

        if error_api or errores_sistema:
            self.texto_estado.color = "#FCA5A5"
        elif guardados and (omitidos or self.errores_importacion):
            self.texto_estado.color = "#FDE68A"
        elif guardados:
            self.texto_estado.color = "#86EFAC"
        else:
            self.texto_estado.color = "#FCA5A5"

        self._actualizar_errores()
        self.page.update()

    @staticmethod
    def _generar_codigo(codigos_usados):
        for _ in range(100):
            codigo = str(secrets.randbelow(9000) + 1000)
            if codigo not in codigos_usados:
                return codigo
        for numero in range(1000, 10000):
            codigo = str(numero)
            if codigo not in codigos_usados:
                return codigo
        raise ValueError("No quedan códigos numéricos de cuatro dígitos disponibles.")

    def _actualizar_errores(self):
        self.lista_errores.controls.clear()
        for error in self.errores_importacion[:8]:
            self.lista_errores.controls.append(
                ft.Text(
                    f'Fila {error["fila"]}: {error["mensaje"]}',
                    color="#FCA5A5",
                    size=12,
                )
            )
        if len(self.errores_importacion) > 8:
            self.lista_errores.controls.append(
                ft.Text(
                    f"Y {len(self.errores_importacion) - 8} errores más.",
                    color="#FCA5A5",
                    size=12,
                )
            )

    def _mostrar_error(self, mensaje):
        self.resultado_excel = None
        self.boton_importar.disabled = True
        self.texto_estado.value = mensaje
        self.texto_estado.color = "#FCA5A5"
        self.page.update()
