import flet as ft
from src.clase.ventana1 import Ventana1
from src.clase.ventana2 import Ventana2
from src.clase.ventana3 import Ventana3
from src.clase.ventana4 import Ventana4
from src.clase.ventana5 import Ventana5
from src.clase.ventana6 import Ventana6


class Pagina:
    def __init__(self, page: ft.Page, tamaño):
        self.page = page
        self.page.title = "Gestión de Productos"
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.page.bgcolor = "#020617"
        self.page.padding = 18

        self.gestion_ventana_1 = Ventana1(page, tamaño)
        self.gestion_ventana_2 = Ventana2(page, tamaño)
        self.gestion_ventana_3 = Ventana3(page, tamaño)
        self.gestion_ventana_4 = Ventana4(page, tamaño)
        self.gestion_ventana_5 = Ventana5(page, tamaño)
        self.gestion_ventana_6 = Ventana6(page, tamaño)
        self.ventana_1 = self.gestion_ventana_1.ventana_1
        self.ventana_2 = self.gestion_ventana_2.ventana_2
        self.ventana_3 = self.gestion_ventana_3.ventana_3
        self.ventana_4 = self.gestion_ventana_4.ventana_4
        self.ventana_5 = self.gestion_ventana_5.ventana_5
        self.ventana_6 = self.gestion_ventana_6.ventana_6
        self.gestion_ventana_1.on_producto_cambiado = self.gestion_ventana_2.actualizar_tabla
        self.gestion_ventana_2.on_editar = self.editar_producto
        self.gestion_ventana_1.on_movimiento = (
            self.gestion_ventana_3.registrar_movimiento
        )
        self.gestion_ventana_2.on_movimiento = (
            self.gestion_ventana_3.registrar_movimiento
        )
        self.gestion_ventana_4.on_movimiento = (
            self.gestion_ventana_3.registrar_movimiento
        )
        self.gestion_ventana_4.on_inventario_cambiado = (
            self.gestion_ventana_2.actualizar_tabla
        )
        self.gestion_ventana_6.on_producto_cambiado = (
            self.gestion_ventana_2.actualizar_tabla
        )
        self.gestion_ventana_6.on_movimiento = (
            self.gestion_ventana_3.registrar_movimiento
        )

        self.boton_ventana_1 = ft.Button(
            content="Nuevo / Editar producto",
            on_click=self.mostrar_ventana_1,
            height=42,
            bgcolor="#1D4ED8",
            color="#FFFFFF",
        )

        self.boton_ventana_2 = ft.Button(
            content="Ver inventario",
            on_click=self.mostrar_ventana_2,
            height=42,
            bgcolor="#1E293B",
            color="#E2E8F0",
        )

        self.boton_ventana_3 = ft.Button(
            content="Cortes y turnos",
            on_click=self.mostrar_ventana_3,
            height=42,
            bgcolor="#1E293B",
            color="#E2E8F0",
        )

        self.boton_ventana_4 = ft.Button(
            content="Productos apartados",
            on_click=self.mostrar_ventana_4,
            height=42,
            bgcolor="#1E293B",
            color="#E2E8F0",
        )

        self.boton_ventana_5 = ft.Button(
            content="Reportes y valor",
            on_click=self.mostrar_ventana_5,
            height=42,
            bgcolor="#1E293B",
            color="#E2E8F0",
        )

        self.boton_ventana_6 = ft.Button(
            content="Importar Excel",
            on_click=self.mostrar_ventana_6,
            height=42,
            bgcolor="#1E293B",
            color="#E2E8F0",
        )

        self.area_contenido = ft.Container(
            content=self.ventana_1,
            expand=True,
        )

        self.control = ft.Column(
            [
                ft.Container(
                    content=ft.Text(
                        "Gestión de Inventario",
                        size=28,
                        weight=ft.FontWeight.BOLD,
                        color="#FFFFFF",
                        text_align=ft.TextAlign.CENTER,
                    ),
                    bgcolor="#111827",
                    border=ft.Border.all(1, "#334155"),
                    border_radius=6,
                    padding=14,
                ),
                ft.Row(
                    [
                        self.boton_ventana_1,
                        self.boton_ventana_2,
                        self.boton_ventana_3,
                        self.boton_ventana_4,
                        self.boton_ventana_5,
                        self.boton_ventana_6,
                    ],
                    spacing=10,
                    wrap=True,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                self.area_contenido,
            ],
            spacing=16,
            expand=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

        self._actualizar_estilo_botones(ventana_activa=1)

    def editar_producto(self, nombre):
        if self.gestion_ventana_1.cargar_producto(nombre):
            self.area_contenido.content = self.ventana_1
            self._actualizar_estilo_botones(ventana_activa=1)
            self.page.update()

    def mostrar_ventana_1(self, evento):
        self.area_contenido.content = self.ventana_1
        self._actualizar_estilo_botones(ventana_activa=1)
        self.page.update()

    def mostrar_ventana_2(self, evento):
        self.area_contenido.content = self.ventana_2
        self._actualizar_estilo_botones(ventana_activa=2)
        self.page.update()

    def mostrar_ventana_3(self, evento):
        self.gestion_ventana_3.actualizar_turno()
        self.gestion_ventana_3.actualizar_cortes()
        self.area_contenido.content = self.ventana_3
        self._actualizar_estilo_botones(ventana_activa=3)
        self.page.update()

    def mostrar_ventana_4(self, evento):
        self.gestion_ventana_4.actualizar_lista()
        self.area_contenido.content = self.ventana_4
        self._actualizar_estilo_botones(ventana_activa=4)
        self.page.update()

    def mostrar_ventana_5(self, evento):
        self.gestion_ventana_5.actualizar()
        self.area_contenido.content = self.ventana_5
        self._actualizar_estilo_botones(ventana_activa=5)
        self.page.update()

    def mostrar_ventana_6(self, evento):
        self.area_contenido.content = self.ventana_6
        self._actualizar_estilo_botones(ventana_activa=6)
        self.page.update()

    def _actualizar_estilo_botones(self, ventana_activa):
        botones = [
            self.boton_ventana_1,
            self.boton_ventana_2,
            self.boton_ventana_3,
            self.boton_ventana_4,
            self.boton_ventana_5,
            self.boton_ventana_6,
        ]
        colores_activos = [
            "#1D4ED8",
            "#6D28D9",
            "#166534",
            "#0E7490",
            "#0369A1",
            "#0F766E",
        ]
        for indice, boton in enumerate(botones):
            activo = indice + 1 == ventana_activa
            boton.bgcolor = colores_activos[indice] if activo else "#1E293B"
            boton.color = "#FFFFFF" if activo else "#E2E8F0"
