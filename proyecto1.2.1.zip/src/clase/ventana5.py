import os

import flet as ft
from src.clase.funciones_obsidian import (
    calcular_valor_inventario,
    eliminar_reporte_cierre,
    leer_cortes,
)
from src.clase.obsidian_api import ObsidianAPIError


class Ventana5:
    def __init__(self, page: ft.Page, tamaño):
        self.page = page
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]

        self.texto_valor_inventario = ft.Text(
            value="$0.00",
            size=26,
            weight=ft.FontWeight.BOLD,
            color="#F8FAFC",
        )
        self.texto_estado = ft.Text(value="", color="#FCA5A5")
        self.lista_reportes = ft.Column(
            controls=[],
            spacing=8,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
        )
        self.detalle_reporte = ft.Column(
            controls=[
                ft.Text(
                    "Selecciona un reporte para consultar todos sus datos.",
                    color="#CBD5E1",
                )
            ],
            spacing=8,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
        )

        self.ventana_5 = ft.Container(
            content=ft.Column(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Reportes de cierre",
                                size=26,
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Consulta los cortes guardados y el detalle completo de sus movimientos.",
                                color="#CBD5E1",
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    "Valor actual del inventario",
                                    color="#BFDBFE",
                                    weight=ft.FontWeight.BOLD,
                                ),
                                self.texto_valor_inventario,
                                ft.Text(
                                    "Calculado como precio × stock disponible; no representa ganancia neta.",
                                    color="#CBD5E1",
                                    size=12,
                                ),
                            ],
                            spacing=4,
                        ),
                        bgcolor="#1E3A5F",
                        border=ft.Border.all(1, "#3B82F6"),
                        border_radius=6,
                        padding=16,
                    ),
                    ft.Row(
                        [
                            ft.Button(
                                content="Actualizar reportes",
                                on_click=self.actualizar,
                                bgcolor="#1D4ED8",
                                color="#FFFFFF",
                                height=42,
                            ),
                            self.texto_estado,
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=12,
                    ),
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            "Reportes guardados",
                                            weight=ft.FontWeight.BOLD,
                                            color="#F8FAFC",
                                        ),
                                        self.lista_reportes,
                                    ],
                                    spacing=8,
                                    expand=True,
                                ),
                                bgcolor="#1E293B",
                                border=ft.Border.all(1, "#475569"),
                                border_radius=6,
                                padding=14,
                                expand=True,
                            ),
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text(
                                            "Detalle del reporte",
                                            weight=ft.FontWeight.BOLD,
                                            color="#F8FAFC",
                                        ),
                                        self.detalle_reporte,
                                    ],
                                    spacing=8,
                                    expand=True,
                                ),
                                bgcolor="#1E293B",
                                border=ft.Border.all(1, "#475569"),
                                border_radius=6,
                                padding=14,
                                expand=True,
                            ),
                        ],
                        spacing=12,
                        expand=True,
                    ),
                ],
                spacing=14,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )
        self.actualizar()

    def actualizar(self, evento=None):
        try:
            valor = calcular_valor_inventario()
        except ValueError as error:
            self.texto_estado.value = str(error)
        else:
            self.texto_valor_inventario.value = f"${valor:,.2f}"
            self.texto_estado.value = ""

        self.lista_reportes.controls.clear()
        reportes = leer_cortes()
        for reporte in reportes:
            titulo = (
                f'{reporte.get("turno", "Turno")} - '
                f'{reporte.get("fecha", "Fecha desconocida")}'
            )
            self.lista_reportes.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                titulo,
                                color="#F8FAFC",
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Text(
                                f'Movimientos: {len(reporte.get("movimientos", []))}',
                                color="#CBD5E1",
                                size=12,
                            ),
                            ft.Button(
                                content="Ver todos los datos",
                                on_click=self.crear_evento_ver(reporte),
                                bgcolor="#334155",
                                color="#FFFFFF",
                            ),
                            ft.Button(
                                content="Eliminar reporte",
                                on_click=self.crear_evento_eliminar(reporte),
                                bgcolor="#7F1D1D",
                                color="#FFFFFF",
                            ),
                        ],
                        spacing=4,
                    ),
                    bgcolor="#334155",
                    border=ft.Border.all(1, "#475569"),
                    border_radius=4,
                    padding=10,
                )
            )

        if not reportes:
            self.lista_reportes.controls.append(
                ft.Text(
                    "Todavía no hay reportes de cierre guardados.",
                    color="#CBD5E1",
                )
            )
        self.page.update()

    def crear_evento_ver(self, reporte):
        def ver(evento):
            self.mostrar_detalle(reporte)

        return ver

    def crear_evento_eliminar(self, reporte):
        def abrir_confirmacion(_evento):
            dialogo = ft.AlertDialog(
                modal=True,
                title=ft.Text("Eliminar reporte"),
                content=ft.Text(
                    "Se eliminarán el reporte y su corte asociado. "
                    "Esta acción no se puede deshacer."
                ),
                actions=[
                    ft.Button(
                        content="Cancelar",
                        on_click=lambda _evento: self.page.pop_dialog(),
                        bgcolor="#334155",
                        color="#FFFFFF",
                    ),
                    ft.Button(
                        content="Eliminar",
                        on_click=self.crear_evento_confirmar_eliminacion(
                            reporte,
                        ),
                        bgcolor="#B91C1C",
                        color="#FFFFFF",
                    ),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
            )
            self.page.show_dialog(dialogo)

        return abrir_confirmacion

    def crear_evento_confirmar_eliminacion(self, reporte):
        def confirmar(_evento):
            self.page.pop_dialog()
            try:
                eliminado = eliminar_reporte_cierre(reporte.get("_archivo", ""))
            except (ObsidianAPIError, ValueError) as error:
                self.texto_estado.value = str(error)
                self.texto_estado.color = "#FCA5A5"
                self.page.update()
                return

            self.detalle_reporte.controls = [
                ft.Text(
                    "Selecciona un reporte para consultar todos sus datos.",
                    color="#CBD5E1",
                )
            ]
            self.actualizar()
            self.texto_estado.value = (
                "Reporte eliminado."
                if eliminado
                else "El reporte ya no estaba disponible."
            )
            self.texto_estado.color = "#86EFAC" if eliminado else "#FCA5A5"
            self.page.update()

        return confirmar

    def mostrar_detalle(self, reporte):
        self.detalle_reporte.controls.clear()
        movimientos = reporte.get("movimientos", [])

        for clave, valor in reporte.items():
            if clave in ("movimientos", "responsable", "_archivo"):
                continue
            if clave == "reporte":
                valor = os.path.basename(str(valor))
            self.detalle_reporte.controls.append(
                ft.Text(
                    f"{clave.replace('_', ' ').capitalize()}: {valor}",
                    color="#E2E8F0",
                    selectable=True,
                )
            )

        self.detalle_reporte.controls.append(
            ft.Text(
                f"Movimientos detallados ({len(movimientos)})",
                color="#93C5FD",
                weight=ft.FontWeight.BOLD,
                size=18,
            )
        )
        if not movimientos:
            self.detalle_reporte.controls.append(
                ft.Text("Este corte no contiene movimientos.", color="#CBD5E1")
            )

        for indice, movimiento in enumerate(movimientos, start=1):
            campos = [
                ft.Text(
                    f"Movimiento {indice}",
                    color="#F8FAFC",
                    weight=ft.FontWeight.BOLD,
                )
            ]
            for clave, valor in movimiento.items():
                campos.append(
                    ft.Text(
                        f"{clave.replace('_', ' ').capitalize()}: {valor}",
                        color="#E2E8F0",
                        selectable=True,
                    )
                )
            self.detalle_reporte.controls.append(
                ft.Container(
                    content=ft.Column(controls=campos, spacing=3),
                    bgcolor="#334155",
                    border=ft.Border.all(1, "#475569"),
                    border_radius=4,
                    padding=10,
                )
            )
        self.page.update()
