import ntpath
import os
from datetime import date, datetime, timedelta

import yaml
from src.clase.obsidian_api import ObsidianAPIError, get_obsidian_api

CARPETA = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "informacion",
    "productos"
)
CARPETA_PROVEEDORES = os.path.join(
    os.path.dirname(CARPETA),
    "proveedores"
)
CARPETA_TURNOS = os.path.join(
    os.path.dirname(CARPETA),
    "turnos"
)
CARPETA_CORTES = os.path.join(
    os.path.dirname(CARPETA),
    "cortes"
)
CARPETA_REPORTES_CIERRE = os.path.join(
    os.path.dirname(CARPETA),
    "reportes_cierre"
)
CARPETA_APARTADOS = os.path.join(
    os.path.dirname(CARPETA),
    "apartados"
)

os.makedirs(CARPETA, exist_ok=True)
os.makedirs(CARPETA_PROVEEDORES, exist_ok=True)
os.makedirs(CARPETA_TURNOS, exist_ok=True)
os.makedirs(CARPETA_CORTES, exist_ok=True)
os.makedirs(CARPETA_REPORTES_CIERRE, exist_ok=True)
os.makedirs(CARPETA_APARTADOS, exist_ok=True)


CARPETAS_DATOS = {
    "proveedores": CARPETA_PROVEEDORES,
    "turnos": CARPETA_TURNOS,
    "cortes": CARPETA_CORTES,
    "reportes_cierre": CARPETA_REPORTES_CIERRE,
    "apartados": CARPETA_APARTADOS,
}


def _leer_nota(ruta):
    return get_obsidian_api().read_note(ruta)


def _guardar_nota(ruta, contenido):
    get_obsidian_api().write_note(ruta, contenido)


def _eliminar_nota(ruta):
    get_obsidian_api().delete_note(ruta)


def _listar_notas(carpeta=""):
    return sorted(
        archivo
        for archivo in get_obsidian_api().list_files(carpeta)
        if archivo.lower().endswith(".md")
    )


def _separar_frontmatter(contenido):
    partes = contenido.split("---", 2)
    if len(partes) < 3:
        raise ValueError("La nota no contiene un bloque YAML válido.")
    return yaml.safe_load(partes[1]) or {}, partes[2].strip()


def migrar_datos_locales_a_obsidian():
    """Copia al vault los registros locales que aún no existen en Obsidian."""
    api = get_obsidian_api()
    api.verify_connection()
    copiados = 0
    ya_existian = 0
    conflictos = 0

    for carpeta_vault, carpeta_local in CARPETAS_DATOS.items():
        if not os.path.isdir(carpeta_local):
            continue
        for archivo in sorted(os.listdir(carpeta_local)):
            if not archivo.lower().endswith(".md"):
                continue
            ruta_local = os.path.join(carpeta_local, archivo)
            if not os.path.isfile(ruta_local):
                continue
            ruta_vault = f"{carpeta_vault}/{archivo}"
            with open(ruta_local, "r", encoding="utf-8") as file:
                contenido_local = file.read()
            contenido_vault = api.read_note(ruta_vault)
            if contenido_vault is not None:
                if contenido_vault == contenido_local:
                    ya_existian += 1
                else:
                    conflictos += 1
                continue
            api.write_note(ruta_vault, contenido_local)
            copiados += 1

    if conflictos:
        raise ObsidianAPIError(
            f"Hay {conflictos} archivos locales con una nota distinta del mismo "
            "nombre en Obsidian. No se sobrescribió ninguna; compara o renombra "
            "los archivos antes de volver a abrir la aplicación."
        )

    return {"copiados": copiados, "ya_existian": ya_existian}


def ruta_nota(nombre):
    """Cada producto es un archivo 'nombre.md'."""
    return f"{nombre_archivo_seguro(nombre)}.md"


def guardar_producto(datos, notas=""):
    """Crea o sobreescribe la nota de un producto ('datos' es un diccionario)."""
    datos = dict(datos)
    for campo in ("precio", "stock", "stock_minimo"):
        if campo in datos:
            try:
                valor = float(datos[campo])
            except (TypeError, ValueError) as error:
                raise ValueError(f"{campo.capitalize()} debe ser un número válido.") from error
            if valor < 0:
                raise ValueError(f"{campo.capitalize()} no puede ser negativo.")

    proveedor = datos.get("proveedor", "").strip()
    proveedor_datos = None

    if proveedor:
        proveedor_datos = buscar_proveedor(proveedor)

    if proveedor_datos:
        datos["proveedor"] = proveedor_datos["nombre"]
        productos = proveedor_datos.setdefault("productos", [])
        referencia = datos["nombre"]
        if referencia not in productos:
            productos.append(referencia)
        guardar_proveedor(proveedor_datos)

    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    _guardar_nota(ruta_nota(datos["nombre"]), f"---\n{yaml_texto}---\n{notas}\n")


def leer_producto(nombre):
    """Lee una nota y devuelve (datos, notas). Regresa None si no existe."""
    ruta = ruta_nota(nombre)
    contenido = _leer_nota(ruta)
    if contenido is None:
        return None
    datos, notas = _separar_frontmatter(contenido)
    return datos, notas


def leer_todos():
    """Devuelve una lista con los datos de todos los productos."""
    productos = []
    for archivo in _listar_notas():
        resultado = leer_producto(archivo[:-3])
        if resultado:
            datos, _ = resultado
            productos.append(datos)
    return productos


def calcular_valor_inventario():
    """Calcula el valor actual del inventario como precio por stock."""
    total = 0.0
    for producto in leer_todos():
        if not producto:
            continue
        nombre = producto.get("nombre", "Producto sin nombre")
        try:
            precio = float(producto.get("precio", 0) or 0)
            stock = int(producto.get("stock", 0) or 0)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"Precio o stock no válido para {nombre}."
            ) from error
        if precio < 0 or stock < 0:
            raise ValueError(f"Precio o stock negativo para {nombre}.")
        total += precio * stock
    return round(total, 2)


def eliminar_producto(nombre):
    """Borra la nota del producto."""
    _eliminar_nota(ruta_nota(nombre))


def ruta_proveedor(nombre):
    """Devuelve la ruta de la nota de un proveedor."""
    return f"proveedores/{nombre_archivo_seguro(nombre)}.md"


def guardar_proveedor(datos):
    """Crea o actualiza la nota de un proveedor."""
    datos = dict(datos)
    nombre = datos["nombre"].strip()
    if not nombre:
        raise ValueError("El nombre del proveedor es obligatorio.")

    datos.setdefault("productos", [])
    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    _guardar_nota(ruta_proveedor(nombre), f"---\n{yaml_texto}---\n")


def leer_proveedor(nombre):
    """Lee un proveedor por nombre. Regresa None si no existe."""
    contenido = _leer_nota(ruta_proveedor(nombre))
    if contenido is None:
        return None
    proveedor, _ = _separar_frontmatter(contenido)
    return proveedor


def leer_todos_proveedores():
    """Devuelve todos los proveedores guardados."""
    proveedores = []
    for archivo in _listar_notas("proveedores"):
        proveedor = leer_proveedor(archivo[:-3])
        if proveedor:
            proveedores.append(proveedor)
    return proveedores


def buscar_proveedor(valor):
    """Busca un proveedor por nombre."""
    valor = str(valor or "").strip().lower()
    if not valor:
        return None

    for proveedor in leer_todos_proveedores():
        if valor == str(proveedor.get("nombre", "")).lower():
            return proveedor
    return None


def buscar_productos(valor):
    """Busca productos por nombre o código, incluso por coincidencia parcial."""
    valor = str(valor or "").strip().lower()
    if not valor:
        return leer_todos()

    resultados = []
    for producto in leer_todos():
        if not producto:
            continue
        campos = (
            str(producto.get("nombre", "")),
            str(producto.get("codigo", "")),
        )
        if any(valor in campo.lower() for campo in campos):
            resultados.append(producto)
    return resultados


def verificar_alertas(dias_caducidad=30):
    """Devuelve alertas de caducidad y stock bajo con datos del proveedor."""
    hoy = date.today()
    alertas_caducidad = []
    alertas_stock = []

    for producto in leer_todos():
        if not producto:
            continue

        nombre = producto.get("nombre", "")
        proveedor_nombre = producto.get("proveedor", "")
        proveedor = buscar_proveedor(proveedor_nombre) if proveedor_nombre else None

        caducidad = producto.get("caducidad", "")
        if caducidad:
            try:
                fecha_caducidad = datetime.strptime(str(caducidad), "%Y-%m-%d").date()
                dias_restantes = (fecha_caducidad - hoy).days

                if dias_restantes <= dias_caducidad:
                    estado = "Caducado" if dias_restantes < 0 else "Próximo a caducar"
                    alertas_caducidad.append({
                        "producto": nombre,
                        "estado": estado,
                        "caducidad": str(caducidad),
                        "dias_restantes": dias_restantes,
                        "proveedor": proveedor,
                    })
            except (TypeError, ValueError):
                pass

        try:
            stock = int(producto.get("stock", 0) or 0)
            minimo = int(producto.get("stock_minimo", 0) or 0)
        except (TypeError, ValueError):
            stock = 0
            minimo = 0

        if stock <= minimo:
            alertas_stock.append({
                "producto": nombre,
                "stock": stock,
                "stock_minimo": minimo,
                "proveedor": proveedor,
            })

    return {
        "caducidad": alertas_caducidad,
        "stock": alertas_stock,
    }


def nombre_archivo_seguro(valor):
    """Convierte un texto en un nombre seguro para archivos."""
    reemplazos = ("/", "\\", ":", "*", "?", '"', "<", ">", "|")
    resultado = str(valor or "").strip()
    for caracter in reemplazos:
        resultado = resultado.replace(caracter, "-")
    return resultado or "Sin nombre"


def registrar_movimiento_turno(turno, datos):
    """Agrega un movimiento al turno y lo guarda en un archivo."""
    turno = nombre_archivo_seguro(turno)
    contenido_actual = leer_turno(turno)

    movimiento = dict(datos)
    movimiento["fecha"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    contenido_actual["movimientos"].append(movimiento)

    yaml_texto = yaml.safe_dump(
        contenido_actual,
        allow_unicode=True,
        sort_keys=False,
    )
    _guardar_nota(f"turnos/{turno}.md", f"---\n{yaml_texto}---\n")
    return movimiento


def leer_turno(turno):
    """Lee los movimientos actuales de un turno."""
    turno = nombre_archivo_seguro(turno)
    contenido = _leer_nota(f"turnos/{turno}.md")
    if contenido is None:
        return {
            "turno": turno,
            "movimientos": [],
        }

    try:
        datos, _ = _separar_frontmatter(contenido)
    except ValueError:
        datos = {}
    datos.setdefault("turno", turno)
    datos.setdefault("movimientos", [])
    return datos


def crear_reporte_cierre_turno(
    turno,
    movimientos=None,
    fecha_cierre=None,
):
    """Crea y guarda un reporte Markdown con todos los movimientos del turno."""
    turno_seguro = nombre_archivo_seguro(turno)
    if movimientos is None:
        movimientos = leer_turno(turno_seguro).get("movimientos", [])
    else:
        movimientos = list(movimientos)

    fecha_cierre = fecha_cierre or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    marca_tiempo = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    nombre_reporte = f"{turno_seguro}_{marca_tiempo}.md"
    ruta_reporte = f"reportes_cierre/{nombre_reporte}"

    lineas = [
        f"# Reporte de cierre - {turno_seguro}",
        "",
        f"- Fecha de cierre: {fecha_cierre}",
        f"- Total de movimientos: {len(movimientos)}",
        "",
        "## Detalle de movimientos",
        "",
    ]

    if movimientos:
        for indice, movimiento in enumerate(movimientos, start=1):
            lineas.extend([
                f"### Movimiento {indice}",
                "",
                "```yaml",
                yaml.safe_dump(
                    movimiento,
                    allow_unicode=True,
                    sort_keys=False,
                    default_flow_style=False,
                ).rstrip(),
                "```",
                "",
            ])
    else:
        lineas.append("No se registraron movimientos durante este turno.")

    _guardar_nota(ruta_reporte, "\n".join(lineas) + "\n")

    return ruta_reporte


def guardar_corte_turno(turno):
    """Guarda el corte y reporte detallado del turno, y limpia sus movimientos."""
    turno_seguro = nombre_archivo_seguro(turno)
    datos_turno = leer_turno(turno_seguro)
    movimientos = list(datos_turno.get("movimientos", []))
    fecha_corte = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ruta_reporte = crear_reporte_cierre_turno(
        turno_seguro,
        movimientos=movimientos,
        fecha_cierre=fecha_corte,
    )

    corte = {
        "turno": turno_seguro,
        "fecha": fecha_corte,
        "movimientos": movimientos,
        "reporte": ruta_reporte,
    }

    nombre_corte = (
        f"{turno_seguro}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
    )
    yaml_texto = yaml.safe_dump(
        corte,
        allow_unicode=True,
        sort_keys=False,
    )
    _guardar_nota(f"cortes/{nombre_corte}.md", f"---\n{yaml_texto}---\n")

    datos_turno["movimientos"] = []
    yaml_turno = yaml.safe_dump(
        datos_turno,
        allow_unicode=True,
        sort_keys=False,
    )
    _guardar_nota(
        f"turnos/{turno_seguro}.md",
        f"---\n{yaml_turno}---\n",
    )

    return corte


def _fecha_corte(fecha):
    if isinstance(fecha, datetime):
        resultado = fecha
    elif isinstance(fecha, date):
        resultado = datetime.combine(fecha, datetime.min.time())
    elif isinstance(fecha, str):
        try:
            resultado = datetime.fromisoformat(fecha)
        except ValueError:
            return None
    else:
        return None

    if resultado.tzinfo is not None:
        resultado = resultado.astimezone().replace(tzinfo=None)
    return resultado


def eliminar_reporte_cierre(archivo_corte):
    """Elimina un reporte y su corte asociado por el nombre del archivo de corte."""
    identificador = str(archivo_corte or "")
    nombre = nombre_archivo_seguro(identificador)
    if not identificador or nombre != identificador:
        raise ValueError("Identificador de reporte no válido.")

    ruta_corte = f"cortes/{nombre}.md"
    contenido = _leer_nota(ruta_corte)
    if contenido is None:
        return False

    corte, _ = _separar_frontmatter(contenido)
    ruta_reporte = str(corte.get("reporte", "") or "")
    nombre_reporte = ntpath.basename(ruta_reporte.replace("/", "\\"))
    if nombre_reporte.lower().endswith(".md"):
        _eliminar_nota(f"reportes_cierre/{nombre_reporte}")
    _eliminar_nota(ruta_corte)
    return True


def eliminar_reportes_vencidos(ahora=None):
    """Elimina automáticamente reportes cuyo cierre tiene más de dos días."""
    fecha_actual = _fecha_corte(ahora) if ahora is not None else datetime.now()
    if fecha_actual is None:
        raise ValueError("La fecha actual para depurar reportes no es válida.")
    fecha_limite = fecha_actual - timedelta(days=2)
    eliminados = 0

    for archivo in _listar_notas("cortes"):
        contenido = _leer_nota(f"cortes/{archivo}")
        if contenido is None:
            continue
        try:
            corte, _ = _separar_frontmatter(contenido)
        except ValueError:
            continue
        fecha_cierre = _fecha_corte(corte.get("fecha"))
        if fecha_cierre is not None and fecha_cierre < fecha_limite:
            if eliminar_reporte_cierre(archivo[:-3]):
                eliminados += 1

    return eliminados


def leer_cortes():
    """Devuelve los cortes guardados, eliminando antes los que vencieron."""
    eliminar_reportes_vencidos()
    cortes = []
    for archivo in reversed(_listar_notas("cortes")):
        contenido = _leer_nota(f"cortes/{archivo}")
        if contenido is None:
            continue
        try:
            corte, _ = _separar_frontmatter(contenido)
            if corte:
                corte["_archivo"] = archivo[:-3]
                cortes.append(corte)
        except ValueError:
            continue
    return cortes


def guardar_apartado(datos):
    """Guarda un producto apartado en su propio archivo."""
    datos = dict(datos)
    if not datos.get("producto"):
        raise ValueError("El producto es obligatorio.")
    if not datos.get("cliente"):
        raise ValueError("El nombre de quien aparta el producto es obligatorio.")

    apartado_id = datetime.now().strftime("%Y%m%d%H%M%S%f")
    datos["fecha"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    yaml_texto = yaml.safe_dump(datos, allow_unicode=True, sort_keys=False)
    _guardar_nota(
        f"apartados/{apartado_id}.md",
        f"---\n{yaml_texto}---\n",
    )
    return apartado_id


def apartar_producto(valor_producto, cantidad, cliente, telefono=""):
    """Aparta una cantidad del inventario y registra el apartado."""
    consulta = str(valor_producto or "").strip().lower()
    if not consulta:
        raise ValueError("Selecciona un producto.")
    if not str(cliente or "").strip():
        raise ValueError("El nombre del cliente es obligatorio.")

    try:
        cantidad = int(cantidad)
    except (TypeError, ValueError) as error:
        raise ValueError("La cantidad debe ser un número entero.") from error
    if cantidad <= 0:
        raise ValueError("La cantidad debe ser mayor que cero.")

    coincidencias = buscar_productos(consulta)
    exactos = [
        producto for producto in coincidencias
        if consulta in (
            str(producto.get("nombre", "")).lower(),
            str(producto.get("codigo", "")).lower(),
        )
    ]
    if len(exactos) == 1:
        producto = exactos[0]
    elif len(exactos) > 1:
        raise ValueError("La búsqueda coincide con más de un producto.")
    elif len(coincidencias) == 1:
        producto = coincidencias[0]
    elif not coincidencias:
        raise ValueError("No se encontró el producto en el inventario.")
    else:
        raise ValueError("Hay varios productos coincidentes; selecciona uno de la lista.")

    try:
        stock_actual = int(producto.get("stock", 0) or 0)
    except (TypeError, ValueError) as error:
        raise ValueError("El stock del producto no es válido.") from error
    if stock_actual < 0:
        raise ValueError("El producto tiene un stock inválido.")
    if cantidad > stock_actual:
        raise ValueError(
            f"Stock insuficiente: hay {stock_actual} unidades disponibles."
        )

    stock_anterior = producto.get("stock", 0)
    producto["stock"] = stock_actual - cantidad
    guardar_producto(producto)
    try:
        apartado_id = guardar_apartado({
            "producto": producto.get("nombre", ""),
            "codigo": producto.get("codigo", ""),
            "cantidad": cantidad,
            "cliente": str(cliente).strip(),
            "telefono": str(telefono or "").strip(),
        })
    except ObsidianAPIError:
        producto["stock"] = stock_anterior
        guardar_producto(producto)
        raise

    return apartado_id, producto


def leer_apartados():
    """Devuelve los apartados guardados, del más reciente al más antiguo."""
    apartados = []
    for archivo in reversed(_listar_notas("apartados")):
        contenido = _leer_nota(f"apartados/{archivo}")
        try:
            apartado, _ = _separar_frontmatter(contenido)
            if apartado:
                apartado["_archivo"] = archivo[:-3]
                apartados.append(apartado)
        except ValueError:
            continue
    return apartados


def eliminar_apartado(apartado_id):
    """Elimina un apartado por su clave interna de archivo."""
    nombre = nombre_archivo_seguro(apartado_id)
    if nombre != apartado_id or not nombre:
        raise ValueError("Identificador de apartado no válido.")
    _eliminar_nota(f"apartados/{nombre}.md")