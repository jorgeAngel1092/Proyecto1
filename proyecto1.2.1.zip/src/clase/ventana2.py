import flet as ft
from src.clase.funciones_obsidian import (
    buscar_productos,
    eliminar_producto,
    leer_todos,
    verificar_alertas,
)


class Ventana2:
    def __init__(self, page: ft.Page, tamaño, on_editar=None):
        self.page = page
        self.page.title = "Gestión de Productos"
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.on_editar = on_editar
        self.on_movimiento = None

        self.texto_resumen = ft.Text(
            value="0 productos",
            weight=ft.FontWeight.BOLD,
            color="#F8FAFC",
        )
        self.texto_stock_bajo = ft.Text(
            value="0 con stock bajo",
            weight=ft.FontWeight.BOLD,
            color="#F8FAFC",
        )
        self.texto_caducidad = ft.Text(
            value="0 próximos a caducar",
            weight=ft.FontWeight.BOLD,
            color="#F8FAFC",
        )
        self.lista_alertas = ft.Column(
            controls=[],
            spacing=8,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
        )
        self.campo_busqueda = ft.TextField(
            label="Buscar por nombre o código",
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.texto_estado = ft.Text(
            value="",
            weight=ft.FontWeight.W_500,
            color="#F8FAFC",
        )
        self.tabla_productos = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Código", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Nombre", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Caducidad", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Precio", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Stock", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Proveedor", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
                ft.DataColumn(ft.Text("Acciones", color="#F8FAFC", weight=ft.FontWeight.BOLD)),
            ],
            rows=[],
            column_spacing=18,
            horizontal_margin=14,
        )

        self.ventana_2 = ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text(
                                        "Catálogo de productos",
                                        size=26,
                                        weight=ft.FontWeight.BOLD,
                                        color="#F8FAFC",
                                        text_align=ft.TextAlign.CENTER,
                                    ),
                                    ft.Text(
                                        "Consulta, edita o elimina los productos guardados.",
                                        color="#CBD5E1",
                                        text_align=ft.TextAlign.CENTER,
                                    ),
                                ],
                                spacing=2,
                            ),
                            ft.Row(
                                [
                                    ft.Button(
                                        content="Actualizar inventario",
                                        on_click=self.actualizar_tabla,
                                        bgcolor="#7C3AED",
                                        color="#FFFFFF",
                                        height=44,
                                    ),
                                ],
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    ft.Row(
                        [
                            self.campo_busqueda,
                            ft.Button(
                                content="Buscar",
                                on_click=self.buscar,
                                bgcolor="#2563EB",
                                color="#FFFFFF",
                                height=44,
                            ),
                            ft.Button(
                                content="Limpiar",
                                on_click=self.limpiar_busqueda,
                                bgcolor="#E2E8F0",
                                color="#334155",
                                height=44,
                            ),
                        ],
                        spacing=10,
                    ),
                    ft.Row(
                        [
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text("Productos", color="#E2E8F0", weight=ft.FontWeight.BOLD),
                                        self.texto_resumen,
                                    ],
                                    spacing=4,
                                ),
                                bgcolor="#1E293B",
                                border=ft.Border.all(1, "#475569"),
                                border_radius=14,
                                padding=16,
                                expand=True,
                            ),
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text("Alertas", color="#FCA5A5", weight=ft.FontWeight.BOLD),
                                        self.texto_stock_bajo,
                                    ],
                                    spacing=4,
                                ),
                                bgcolor="#450A0A",
                                border=ft.Border.all(1, "#B91C1C"),
                                border_radius=14,
                                padding=16,
                                expand=True,
                            ),
                            ft.Container(
                                content=ft.Column(
                                    [
                                        ft.Text("Caducidad", color="#FCA5A5", weight=ft.FontWeight.BOLD),
                                        self.texto_caducidad,
                                    ],
                                    spacing=4,
                                ),
                                bgcolor="#450A0A",
                                border=ft.Border.all(1, "#B91C1C"),
                                border_radius=14,
                                padding=16,
                                expand=True,
                            ),
                        ],
                        spacing=12,
                    ),
                    self.texto_estado,
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(
                                    "Alertas detalladas",
                                    weight=ft.FontWeight.BOLD,
                                    color="#F8FAFC",
                                ),
                                self.lista_alertas,
                            ],
                            spacing=8,
                            expand=True,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=16,
                        padding=14,
                        height=230,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [self.tabla_productos],
                                    scroll=ft.ScrollMode.AUTO,
                                )
                            ],
                            scroll=ft.ScrollMode.AUTO,
                            expand=True,
                        ),
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=16,
                        padding=8,
                        expand=True,
                    ),
                ],
                spacing=12,
                expand=True,
                scroll=ft.ScrollMode.AUTO,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )

        self.actualizar_tabla()

    def buscar(self, evento=None):
        productos = buscar_productos(self.campo_busqueda.value)
        self.actualizar_tabla(productos=productos)

    def limpiar_busqueda(self, evento=None):
        self.campo_busqueda.value = ""
        self.actualizar_tabla()

    def actualizar_tabla(self, evento=None, productos=None):
        self.tabla_productos.rows.clear()
        if productos is None:
            productos = leer_todos()
        stock_bajo = 0
        alertas = verificar_alertas(dias_caducidad=30)
        self.lista_alertas.controls.clear()

        for datos in productos:
            if not datos:
                continue

            nombre = datos.get("nombre", "")
            stock = int(datos.get("stock", 0) or 0)
            minimo = int(datos.get("stock_minimo", 0) or 0)
            if stock <= minimo:
                stock_bajo += 1

            self.tabla_productos.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(str(datos.get("codigo", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(nombre, weight=ft.FontWeight.BOLD, color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(datos.get("caducidad", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(datos.get("precio", "")), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(stock), color="#F1F5F9")),
                        ft.DataCell(ft.Text(str(datos.get("proveedor", "")), color="#F1F5F9")),
                        ft.DataCell(
                            ft.Row(
                                [
                                    ft.Button(
                                        content="Editar",
                                        on_click=self.crear_evento_editar(nombre),
                                        bgcolor="#DBEAFE",
                                        color="#1D4ED8",
                                        height=36,
                                    ),
                                    ft.Button(
                                        content="Eliminar",
                                        on_click=self.crear_evento_eliminar(nombre),
                                        bgcolor="#FEE2E2",
                                        color="#B91C1C",
                                        height=36,
                                    ),
                                ],
                                spacing=6,
                            )
                        ),
                    ]
                )
            )

        self.texto_resumen.value = f"{len(productos)} productos"
        self.texto_stock_bajo.value = f"{stock_bajo} con stock bajo"
        self.texto_caducidad.value = (
            f"{len(alertas['caducidad'])} próximos a caducar"
        )

        for alerta in alertas["stock"]:
            proveedor = alerta["proveedor"] or {}
            nombre_proveedor = proveedor.get("nombre", "Sin proveedor asignado")
            telefono = proveedor.get("telefono", "No registrado")
            self.lista_alertas.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                f"Stock bajo: {alerta['producto']} "
                                f"({alerta['stock']} de {alerta['stock_minimo']} mínimo)",
                                weight=ft.FontWeight.BOLD,
                                color="#FCA5A5",
                            ),
                            ft.Text(
                                f"Proveedor: {nombre_proveedor} | "
                                f"Teléfono: {telefono}",
                                size=12,
                                color="#FECACA",
                            ),
                        ],
                        spacing=2,
                    ),
                    bgcolor="#450A0A",
                    border=ft.Border.all(1, "#B91C1C"),
                    border_radius=10,
                    padding=10,
                )
            )

        for alerta in alertas["caducidad"]:
            proveedor = alerta["proveedor"] or {}
            nombre_proveedor = proveedor.get("nombre", "Sin proveedor asignado")
            telefono = proveedor.get("telefono", "No registrado")
            dias = alerta["dias_restantes"]
            detalle_dias = "ya caducó" if dias < 0 else f"faltan {dias} días"
            self.lista_alertas.controls.append(
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                f"{alerta['estado']}: {alerta['producto']} "
                                f"({detalle_dias})",
                                weight=ft.FontWeight.BOLD,
                                color="#FCA5A5",
                            ),
                            ft.Text(
                                f"Caducidad: {alerta['caducidad']} | "
                                f"Proveedor: {nombre_proveedor} | "
                                f"Teléfono: {telefono}",
                                size=12,
                                color="#FECACA",
                            ),
                        ],
                        spacing=2,
                    ),
                    bgcolor="#450A0A",
                    border=ft.Border.all(1, "#B91C1C"),
                    border_radius=10,
                    padding=10,
                )
            )

        if not self.lista_alertas.controls:
            self.lista_alertas.controls.append(
                ft.Container(
                    content=ft.Text(
                        "No hay alertas activas.",
                        color="#166534",
                        weight=ft.FontWeight.BOLD,
                    ),
                    bgcolor="#F0FDF4",
                    border=ft.Border.all(1, "#BBF7D0"),
                    border_radius=10,
                    padding=12,
                )
            )

        self.texto_estado.value = ""
        self.page.update()

    def crear_evento_editar(self, nombre):
        def editar(evento):
            if self.on_movimiento:
                self.on_movimiento("Edición de producto", nombre)
            if self.on_editar:
                self.on_editar(nombre)

        return editar

    def crear_evento_eliminar(self, nombre):
        def eliminar(evento):
            eliminar_producto(nombre)
            if self.on_movimiento:
                self.on_movimiento("Producto eliminado", nombre)
            self.texto_estado.value = f'Producto "{nombre}" eliminado.'
            self.texto_estado.color = "#166534"
            self.actualizar_tabla()

        return eliminar