import flet as ft
from src.clase.funciones_obsidian import (
    guardar_producto,
    guardar_proveedor,
    leer_producto,
    leer_proveedor,
    buscar_proveedor,
)

class Ventana1:
    def __init__(self, page: ft.Page, tamaño, on_producto_cambiado=None):
        self.page = page
        self.page.title = "Gestión de Productos"
        self.page.window.width = tamaño[0]
        self.page.window.height = tamaño[1]
        self.on_producto_cambiado = on_producto_cambiado
        self.on_movimiento = None

        self.campo_nombre = ft.TextField(
            label="Nombre",
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_caducidad = ft.TextField(
            label="Caducidad (AAAA-MM-DD)",
            hint_text="Opcional",
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_precio = ft.TextField(
            label="Precio",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_stock = ft.TextField(
            label="Stock",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )

        self.campo_Codigo = ft.TextField(
            label="Codigo",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_stock_minimo = ft.TextField(
            label="Stock mínimo",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_proveedor = ft.TextField(
            label="Proveedor",
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.campo_proveedor_telefono = ft.TextField(
            label="Teléfono del proveedor",
            border_radius=10,
            filled=True,
            bgcolor="#FFFFFF",
            expand=True,
        )
        self.texto_estado = ft.Text(
            value="",
            weight=ft.FontWeight.W_500,
            color="#F8FAFC",
        )

        self.ventana_1 = ft.Container(
            content=ft.Column(
                [
                    ft.Column(
                        [
                            ft.Text(
                                "Registro de inventarios",
                                size=26,
                                weight=ft.FontWeight.BOLD,
                                color="#F8FAFC",
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Registra o actualiza la información de un producto.",
                                color="#CBD5E1",
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=2,
                    ),
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Row(
                                    [
                                        ft.Container(
                                            content=self.campo_Codigo,
                                            expand=True,
                                        ),
                                        ft.Container(
                                            content=self.campo_stock,
                                            expand=True,
                                        ),
                                    ],
                                    spacing=12,
                                ),
                                ft.Row(
                                    [
                                        ft.Container(
                                            content=self.campo_nombre,
                                            expand=True,
                                        ),
                                        ft.Container(
                                            content=self.campo_caducidad,
                                            expand=True,
                                        ),
                                    ],
                                    spacing=12,
                                ),
                                ft.Row(
                                    [
                                        ft.Container(
                                            content=self.campo_precio,
                                            expand=True,
                                        ),
                                        ft.Container(
                                            content=self.campo_stock_minimo,
                                            expand=True,
                                        ),
                                    ],
                                    spacing=12,
                                ),
                                    ft.Text(
                                        "Datos del proveedor",
                                        weight=ft.FontWeight.BOLD,
                                        color="#D7E2F2",
                                    ),
                                    ft.Row(
                                        [
                                            ft.Container(
                                                content=self.campo_proveedor,
                                                expand=True,
                                            ),
                                            ft.Container(
                                                content=self.campo_proveedor_telefono,
                                                expand=True,
                                            ),
                                        ],
                                        spacing=12,
                                    ),
                                    ft.Row(
                                        [
                                            ft.Button(
                                                content="Guardar",
                                                on_click=self.guardar,
                                                bgcolor="#3157A4",
                                                color="#FFFFFF",
                                                height=44,
                                            ),
                                            ft.Button(
                                                content="Guardar proveedor",
                                                on_click=self.agregar_proveedor,
                                                bgcolor="#7A5AF8",
                                                color="#FFFFFF",
                                                height=44,
                                            ),
                                            ft.Button(
                                                content="Limpiar",
                                                on_click=self.limpiar,
                                                bgcolor="#334155",
                                                color="#FFFFFF",
                                                height=44,
                                            ),
                                        ],
                                        spacing=10,
                                        alignment=ft.MainAxisAlignment.CENTER,
                                    ),
                                    self.texto_estado,
                            ],
                            spacing=14,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                            padding=22,
                        bgcolor="#1E293B",
                        border=ft.Border.all(1, "#475569"),
                        border_radius=6,
                        shadow=ft.BoxShadow(
                            blur_radius=18,
                            color="#02061733",
                            offset=ft.Offset(0, 5),
                        ),
                    ),
                ],
                spacing=14,
                scroll=ft.ScrollMode.AUTO,
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            bgcolor="#0F172A",
            border_radius=6,
            padding=24,
            expand=True,
        )

    def limpiar(self, evento=None):
        self.campo_Codigo.value = ""
        self.campo_nombre.value = ""
        self.campo_caducidad.value = ""
        self.campo_precio.value = ""
        self.campo_stock.value = ""
        self.campo_stock_minimo.value = ""
        self.campo_proveedor.value = ""
        self.campo_proveedor_telefono.value = ""
        self.texto_estado.value = ""
        self.page.update()

    def agregar_proveedor(self, evento):
        nombre = self.campo_proveedor.value.strip()
        if not nombre:
            self.texto_estado.value = "Escribe el nombre del proveedor."
            self.texto_estado.color = "#B91C1C"
            self.page.update()
            return

        proveedor_existente = buscar_proveedor(nombre)

        datos = {
            "nombre": nombre,
            "telefono": self.campo_proveedor_telefono.value.strip(),
            "productos": (proveedor_existente or {}).get("productos", []),
        }
        guardar_proveedor(datos)
        if self.on_movimiento:
            self.on_movimiento(
                "Proveedor agregado",
                f"{nombre} | Teléfono: {datos['telefono'] or 'No registrado'}",
            )
        self.texto_estado.value = f'Proveedor "{nombre}" agregado.'
        self.texto_estado.color = "#166534"
        self.page.update()

    def guardar(self, evento):
        nombre = self.campo_nombre.value.strip()
        if not nombre:
            self.texto_estado.value = "El nombre es obligatorio."
            self.texto_estado.color = "#B91C1C"
            self.page.update()
            return

        try:
            precio = float(self.campo_precio.value or 0)
            stock = int(self.campo_stock.value or 0)
            stock_minimo = int(self.campo_stock_minimo.value or 0)
        except ValueError:
            self.texto_estado.value = "Precio, stock y mínimo deben ser números válidos."
            self.texto_estado.color = "#B91C1C"
            self.page.update()
            return
        if precio < 0 or stock < 0 or stock_minimo < 0:
            self.texto_estado.value = "Precio, stock y mínimo no pueden ser negativos."
            self.texto_estado.color = "#B91C1C"
            self.page.update()
            return

        datos = {
            "codigo": self.campo_Codigo.value.strip(),
            "nombre": nombre,
            "caducidad": self.campo_caducidad.value.strip(),
            "precio": precio,
            "stock": stock,
            "stock_minimo": stock_minimo,
            "proveedor": self.campo_proveedor.value.strip(),
        }

        guardar_producto(datos)
        if self.on_movimiento:
            self.on_movimiento(
                "Producto guardado",
                f'{datos["codigo"] or "Sin código"} - {nombre} | Stock: {stock}',
            )
        self.texto_estado.value = f'Producto "{nombre}" guardado.'
        self.texto_estado.color = "#166534"
        if self.on_producto_cambiado:
            self.on_producto_cambiado()
        self.page.update()

    def cargar_producto(self, nombre):
        resultado = leer_producto(nombre)
        if resultado is None:
            return False

        datos, _ = resultado
        if datos:
            self.campo_Codigo.value = str(datos.get("codigo", ""))
            self.campo_nombre.value = str(datos.get("nombre", ""))
            self.campo_caducidad.value = str(datos.get("caducidad", ""))
            self.campo_precio.value = str(datos.get("precio", ""))
            self.campo_stock.value = str(datos.get("stock", ""))
            self.campo_stock_minimo.value = str(datos.get("stock_minimo", ""))
            self.campo_proveedor.value = str(datos.get("proveedor", ""))
            proveedor = (
                buscar_proveedor(self.campo_proveedor.value)
                or leer_proveedor(self.campo_proveedor.value)
            )
            if proveedor:
                self.campo_proveedor_telefono.value = str(proveedor.get("telefono", ""))
        self.texto_estado.value = f'Editando "{nombre}".'
        self.texto_estado.color = "#1D4ED8"
        self.page.update()
        return True


