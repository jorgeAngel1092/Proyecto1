import asyncio
import logging
from pathlib import Path

import flet as ft

from src.clase.funciones_obsidian import migrar_datos_locales_a_obsidian
from src.clase.obsidian_api import ObsidianAPIError
from src.clase.pagina import Pagina


logger = logging.getLogger(__name__)
IMAGEN_INICIO = (
    Path(__file__).resolve().parent
    / "src"
    / "img"
    / "image.jpeg"
)


def _mostrar_error(page, titulo, mensaje):
    page.add(
        ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        titulo,
                        size=24,
                        weight=ft.FontWeight.BOLD,
                        color="#F8FAFC",
                    ),
                    ft.Text(mensaje, color="#FCA5A5"),
                    ft.Text(
                        "Comprueba que la carpeta del vault esté disponible "
                        "y que la aplicación tenga permisos de escritura.",
                        color="#CBD5E1",
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=12,
            ),
            bgcolor="#1E293B",
            padding=24,
            border_radius=6,
            alignment=ft.Alignment.CENTER,
        )
    )


def _manejar_error_no_controlado(page, evento):
    logger.error("Error no controlado en la interfaz: %s", evento.data)
    page.show_dialog(
        ft.AlertDialog(
            modal=True,
            title=ft.Text("Ocurrió un error"),
            content=ft.Text(
                "La operación no pudo completarse. Revisa la terminal para ver "
                "el detalle técnico y vuelve a intentarlo."
            ),
            actions=[
                ft.Button(
                    content="Cerrar",
                    on_click=lambda _: page.pop_dialog(),
                )
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
    )


async def _mostrar_aplicacion(page, imagen):
    try:
        for indice in range(8):
            imagen.opacity = 0.45 if indice % 2 == 0 else 1
            page.update()
            await asyncio.sleep(0.5)

        page.window.full_screen = False
        page.window.width = 900
        page.window.height = 650
        page.padding = 18
        page.controls.clear()
        pagina = Pagina(page, tamaño=(900, 650))
        page.add(pagina.control)
        page.update()
    except Exception:
        logger.exception("Error al mostrar la aplicación después de la animación")
        page.window.full_screen = False
        page.padding = 18
        page.controls.clear()
        _mostrar_error(
            page,
            "No se pudo mostrar la aplicación",
            "Ocurrió un error inesperado. Revisa la terminal para ver el detalle.",
        )
        page.update()


def main(page: ft.Page):
    page.on_error = lambda evento: _manejar_error_no_controlado(page, evento)
    try:
        migrar_datos_locales_a_obsidian()
        imagen_bytes = IMAGEN_INICIO.read_bytes()
        page.title = "StockClean"
        page.window.full_screen = False
        page.window.width = 900
        page.window.height = 650
        page.padding = 0
        imagen = ft.Image(
            src=imagen_bytes,
            fit=ft.BoxFit.CONTAIN,
            expand=True,
            opacity=1,
            animate_opacity=ft.Animation(
                duration=500,
                curve=ft.AnimationCurve.EASE_IN_OUT,
            ),
        )
        page.add(
            ft.Container(
                content=imagen,
                expand=True,
                bgcolor="#FFFFFF",
                alignment=ft.Alignment.CENTER,
            )
        )
        page.update()
        page.run_task(_mostrar_aplicacion, page, imagen)
    except ObsidianAPIError as error:
        page.title = "Almacenamiento local"
        page.bgcolor = "#020617"
        _mostrar_error(page, "No se pudo acceder al vault local", str(error))
    except Exception:
        logger.exception("Error al iniciar la aplicación")
        page.title = "Error al iniciar"
        page.bgcolor = "#020617"
        _mostrar_error(
            page,
            "No se pudo iniciar la aplicación",
            "Ocurrió un error inesperado. Revisa la terminal para ver el detalle.",
        )



if __name__ == "__main__":
    ft.run(main)