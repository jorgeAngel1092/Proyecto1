from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[2]
VAULT_DIR = ROOT_DIR / "src" / "informacion" / "productos"


class ObsidianAPIError(RuntimeError):
    """Error de acceso al vault local de Obsidian."""


class ObsidianLocalAPI:
    def __init__(self):
        try:
            VAULT_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            raise ObsidianAPIError(
                f"No se pudo preparar el vault local en {VAULT_DIR}."
            ) from error
        self._vault = VAULT_DIR.resolve()

    def _resolve_path(self, path, *, directory=False):
        raw_path = str(path or "").replace("\\", "/").strip("/")
        if not raw_path:
            return self._vault if directory else self._vault

        parts = raw_path.split("/")
        if any(part in ("", ".", "..") for part in parts):
            raise ObsidianAPIError("La ruta de Obsidian no es válida.")
        if any(part.lower() == ".obsidian" for part in parts):
            raise ObsidianAPIError(
                "No se permite acceder a la configuración de Obsidian."
            )

        target = (self._vault.joinpath(*parts)).resolve()
        if target != self._vault and self._vault not in target.parents:
            raise ObsidianAPIError("La ruta está fuera del vault local.")
        return target

    def verify_connection(self):
        if not self._vault.is_dir():
            raise ObsidianAPIError(
                f"No se encontró el vault local en {self._vault}."
            )

    def read_note(self, path):
        target = self._resolve_path(path)
        if not target.is_file():
            return None
        try:
            return target.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            raise ObsidianAPIError(
                f"No se pudo leer la nota local {path}."
            ) from error

    def list_files(self, folder=""):
        target = self._resolve_path(folder, directory=True)
        if not target.is_dir():
            return []
        try:
            return sorted(
                item.name
                for item in target.iterdir()
                if item.is_file()
            )
        except OSError as error:
            raise ObsidianAPIError(
                f"No se pudo listar la carpeta local {folder or 'raíz'}."
            ) from error

    def write_note(self, path, content):
        target = self._resolve_path(path)
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        except (OSError, UnicodeEncodeError) as error:
            raise ObsidianAPIError(
                f"No se pudo guardar la nota local {path}."
            ) from error

    def delete_note(self, path):
        target = self._resolve_path(path)
        try:
            if target.is_file() or target.is_symlink():
                target.unlink()
        except OSError as error:
            raise ObsidianAPIError(
                f"No se pudo eliminar la nota local {path}."
            ) from error


_api = None


def get_obsidian_api():
    global _api
    if _api is None:
        _api = ObsidianLocalAPI()
    return _api
